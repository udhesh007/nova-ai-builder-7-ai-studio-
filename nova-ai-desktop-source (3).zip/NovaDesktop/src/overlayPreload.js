'use strict';
const { contextBridge, ipcRenderer } = require('electron');
const ALLOWED = new Set(['overlay:toggle', 'overlay:hide', 'overlay:quit', 'overlay:openMain', 'overlay:ask', 'capture:list', 'capture:take']);
contextBridge.exposeInMainWorld('novaOverlay', {
  invoke: (channel, ...args) =>
    ALLOWED.has(channel) ? ipcRenderer.invoke(channel, ...args) : Promise.reject(new Error('Blocked channel')),
});
