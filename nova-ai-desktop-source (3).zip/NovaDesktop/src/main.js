'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell, safeStorage, nativeImage } = require('electron');
const path = require('path');
const os = require('os');
const fs = require('fs');
const { Store } = require('./core/store');
const providers = require('./core/providers');
const F = require('./core/fsTools');
const { createPdf } = require('./core/pdf');
const { exportToPath } = require('./core/exporters');
const { analyzeFile } = require('./core/analyze');
const FE = require('./core/fileEdits');
const imageGen = require('./core/imageGen');
const { createOverlayController } = require('./overlay');

let store;
let win;
let overlay;
let quitting = false;
const aborts = new Map();       // requestId -> AbortController
const createdPaths = new Set(); // files the user chose to create via a Save dialog
let scanToken = null;

if (!app.requestSingleInstanceLock()) app.quit();

const SETTING_KEYS = [
  'provider', 'baseUrl', 'model', 'timeoutSec', 'systemPrompt', 'host', 'port', 'localModel', 'cloudPreset', 'visionModel',
  'overlayEnabled', 'aiEditMode', 'imageBackend', 'imageUrl', 'imageModel', 'imageSteps', 'imageWidth', 'imageHeight', 'imageNegative',
];
const VISION_HINT = 'Images need a vision-capable model. Text-only models (for example qwen2.5) cannot read images. Open Settings and set a “Vision model” (for Ollama, for example qwen2.5vl:3b or minicpm-v after “ollama pull”), or use a Gemini Flash model.';
const IMG_EXT = new Set(['png', 'jpg', 'jpeg']);
const extOf = (p) => path.extname(p).slice(1).toLowerCase();

// ---------------------------------------------------------------- app-owned folders
const dirOf = (name) => { const d = path.join(app.getPath('userData'), name); fs.mkdirSync(d, { recursive: true }); return d; };
const roots = () => store.getSettings().folders;
const allowedImageRoots = () => [...roots(), dirOf('captures'), dirOf('generated')];

function cleanOldCaptures() {
  try {
    const dir = dirOf('captures');
    for (const f of fs.readdirSync(dir)) {
      const p = path.join(dir, f);
      if (Date.now() - fs.statSync(p).mtimeMs > 14 * 86400000) fs.unlinkSync(p);
    }
  } catch { /* best effort */ }
}

// ---------------------------------------------------------------- windows
function createWindow() {
  win = new BrowserWindow({
    width: 1180, height: 780, minWidth: 900, minHeight: 600, backgroundColor: '#060a18', title: 'NOVA AI',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true,
    },
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  // With the floating button on, closing the window keeps NOVA running in the background (quit from the tray or panel).
  win.on('close', (e) => { if (!quitting && overlay && overlay.isRunning()) { e.preventDefault(); win.hide(); } });
}

function showMain() {
  if (!win || win.isDestroyed()) createWindow();
  else { if (win.isMinimized()) win.restore(); win.show(); win.focus(); }
}

function quitApp() { quitting = true; app.quit(); }

// ---------------------------------------------------------------- helpers
function providerConfig(over = {}) {
  const s = store.getSettings();
  return {
    kind: s.provider, baseUrl: s.baseUrl, apiKey: store.getApiKey(),
    model: s.provider === 'cloud' ? s.model : s.localModel,
    timeoutSec: s.timeoutSec, host: s.host, port: s.port, ...over,
  };
}

/** Provider config for a request; when it contains images, the optional "Vision model" is used instead. */
function configFor(hasImages) {
  const s = store.getSettings();
  return hasImages && s.visionModel && s.visionModel.trim() ? providerConfig({ model: s.visionModel.trim() }) : providerConfig();
}

function handle(channel, fn) {
  ipcMain.handle(channel, async (event, ...args) => {
    try {
      if (!event.senderFrame || !String(event.senderFrame.url).startsWith('file://')) throw new Error('Blocked request.');
      return { ok: true, data: await fn(...args) };
    } catch (err) {
      return { ok: false, error: err && err.message ? err.message : String(err) };
    }
  });
}

/** Any readable PNG/JPEG -> resized JPEG as base64 (for vision models). */
function visionB64(src) {
  const img = typeof src === 'string' ? nativeImage.createFromPath(src) : nativeImage.createFromBuffer(src);
  if (img.isEmpty()) throw new Error('This image cannot be read. Use a PNG or JPEG image.');
  const { width } = img.getSize();
  return (width > 1600 ? img.resize({ width: 1600, quality: 'good' }) : img).toJPEG(80).toString('base64');
}

async function chatWithHint(cfg, messages, opts, hasImages) {
  try { return await providers.chat(cfg, messages, opts); } catch (e) {
    if (hasImages && e instanceof providers.AiError && !/Cancelled/.test(e.message)) throw new Error(e.message + ' ' + VISION_HINT);
    throw e;
  }
}

async function buildApiMessages(messages, { allowEdits = false } = {}) {
  const s = store.getSettings();
  let budget = 150000;
  let imagesUsed = false;
  let editable = [];
  const processed = [];
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m.error) continue;
    let content = String(m.content || '');
    let images;
    if (m.role === 'user') {
      const atts = Array.isArray(m.attachments) ? m.attachments : [];
      const imgPaths = [...(Array.isArray(m.images) ? m.images : []).map((x) => x.path), ...atts.filter((a) => IMG_EXT.has(extOf(a.path))).map((a) => a.path)];
      if (imgPaths.length) {
        if (!imagesUsed) {
          imagesUsed = true;
          images = [];
          for (const p of imgPaths.slice(0, 3)) {
            try { F.assertInside(allowedImageRoots(), p); images.push(visionB64(p)); } catch (e) { content += `\n[Image ${path.basename(p)} could not be used: ${e.message}]`; }
          }
        } else content = '[An image was attached here earlier and is not re-sent.]\n' + content;
      }
      const blocks = [];
      for (const a of atts.filter((x) => !IMG_EXT.has(extOf(x.path)))) {
        const name = path.basename(String(a.path));
        try {
          const r = await F.readForAI(roots(), a.path, { maxChars: Math.min(60000, Math.max(2000, budget)) });
          budget -= r.text.length;
          blocks.push(`[Attached file: ${name}${r.truncated ? ' (truncated)' : ''}]\n${r.text || '(no readable text: ' + r.note + ')'}\n[End of file]`);
        } catch (e) { blocks.push(`[Attached file ${name} could not be read: ${e.message}]`); }
      }
      if (blocks.length) content = blocks.join('\n\n') + '\n\n' + content;
      if (allowEdits && i === messages.length - 1) {
        editable = atts.filter((a) => F.TEXT_EXT.has(extOf(a.path))).map((a) => a.path);
      }
    }
    const item = { role: m.role === 'assistant' ? 'assistant' : 'user', content };
    if (images && images.length) item.images = images;
    processed.unshift(item);
  }
  const out = [];
  let sys = (s.systemPrompt || '').trim();
  if (editable.length) sys = (sys ? sys + '\n\n' : '') + FE.editSystemPrompt(editable);
  if (sys) out.push({ role: 'system', content: sys });
  return { api: out.concat(processed.slice(-40)), editable, hasImages: imagesUsed };
}

function stripFence(t) {
  let r = t.trim();
  if (r.startsWith('```') && r.endsWith('```') && r.length > 6) r = r.slice(r.indexOf('\n') + 1).replace(/```$/, '').trimEnd();
  return r;
}

const imageCfg = (over = {}) => {
  const s = store.getSettings();
  return {
    backend: s.imageBackend, url: s.imageUrl, steps: s.imageSteps, width: s.imageWidth, height: s.imageHeight, negative: s.imageNegative,
    cloudUrl: s.baseUrl, apiKey: store.getApiKey(), model: s.imageModel, ...over,
  };
};

const ANALYSIS_PROMPTS = {
  objects: 'List every distinct object you can detect in this image as a bullet list. For each give a label, a confidence (high/medium/low) and a rough position (for example top-left). Do not invent objects.',
  ocr: 'Transcribe all visible text in this image exactly as written, preserving line breaks. If there is no text, say so.',
  describe: 'Describe this image in detail.',
};

// ---------------------------------------------------------------- IPC
function register() {
  handle('settings:get', () => ({
    settings: store.getSettings(), hasKey: store.hasApiKey(), secure: store.secureAvailable(),
    version: app.getVersion(), sep: path.sep, home: os.homedir(), overlayRunning: overlay.isRunning(),
  }));
  handle('settings:save', ({ settings = {}, apiKey } = {}) => {
    const patch = {};
    for (const k of SETTING_KEYS) if (k in settings) patch[k] = settings[k];
    for (const k of ['timeoutSec', 'imageSteps', 'imageWidth', 'imageHeight']) if (k in patch) patch[k] = Number(patch[k]);
    for (const k of ['baseUrl', 'model', 'host', 'port', 'localModel', 'imageUrl', 'imageModel', 'visionModel']) if (k in patch) patch[k] = String(patch[k]).trim();
    if ('overlayEnabled' in patch) patch.overlayEnabled = Boolean(patch.overlayEnabled);
    if ('aiEditMode' in patch && !['apply', 'review'].includes(patch.aiEditMode)) patch.aiEditMode = 'apply';
    store.saveSettings(patch);
    let persisted = true;
    if (typeof apiKey === 'string' && apiKey.trim()) persisted = store.setApiKey(apiKey.trim()).persisted;
    if ('overlayEnabled' in patch) { if (patch.overlayEnabled) overlay.start(); else overlay.stop(); }
    return { persisted };
  });
  handle('settings:deleteKey', () => { store.deleteApiKey(); return true; });
  handle('provider:test', async (cfg = {}) => providers.testConnection(
    providerConfig({ ...cfg, apiKey: cfg.apiKey && cfg.apiKey.trim() ? cfg.apiKey.trim() : store.getApiKey() })));
  handle('provider:models', async ({ host, port } = {}) => providers.listOllamaModels({ host, port, timeoutSec: 10 }));
  handle('provider:cloudModels', async ({ baseUrl, apiKey } = {}) => providers.listCloudModels({
    baseUrl: baseUrl || store.getSettings().baseUrl, apiKey: apiKey && apiKey.trim() ? apiKey.trim() : store.getApiKey(), timeoutSec: 20,
  }));

  handle('chat:send', async ({ requestId, messages, allowEdits }) => {
    const ctrl = new AbortController();
    aborts.set(requestId, ctrl);
    try {
      const { api, editable, hasImages } = await buildApiMessages(messages, { allowEdits: Boolean(allowEdits) });
      let reply = await chatWithHint(configFor(hasImages), api, { signal: ctrl.signal }, hasImages);
      let edits = [];
      if (editable.length) {
        const blocks = FE.parseEditBlocks(reply);
        if (blocks.length) { edits = await FE.applyEdits(roots(), editable, blocks); reply = FE.stripEditBlocks(reply) || 'Done.'; }
      }
      return { reply, edits };
    } finally { aborts.delete(requestId); }
  });
  handle('chat:cancel', (id) => { aborts.get(id)?.abort(); return true; });

  handle('conv:list', () => store.listConversations());
  handle('conv:get', (id) => store.getConversation(id));
  handle('conv:save', (c) => store.saveConversation(c));
  handle('conv:rename', ({ id, title }) => { store.renameConversation(id, title); return true; });
  handle('conv:delete', (id) => { store.deleteConversation(id); return true; });
  handle('conv:clear', () => { store.clearConversations(); return true; });

  handle('folders:add', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Choose a folder NOVA AI may use', properties: ['openDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null;
    const p = F.realpathNearest(r.filePaths[0]);
    const broad = path.parse(p).root === p || p === os.homedir();
    if (broad) {
      const c = await dialog.showMessageBox(win, {
        type: 'warning', buttons: ['Cancel', 'Grant access'], defaultId: 0, cancelId: 0,
        message: `Give NOVA AI access to everything inside\n${p}?`,
        detail: 'NOVA only reads or changes files when you press a button or ask it to, never uploads files by itself, and never deletes files. Edits always keep a .nova-bak backup. You can remove this folder at any time.',
      });
      if (c.response !== 1) return null;
    }
    const s = store.getSettings();
    if (!s.folders.includes(p)) store.saveSettings({ folders: [...s.folders, p] });
    return store.getSettings().folders;
  });
  handle('folders:remove', (p) => store.saveSettings({ folders: store.getSettings().folders.filter((f) => f !== p) }).folders);

  handle('fs:list', (dir) => F.listDir(roots(), dir));
  const scan = async (fn) => {
    if (scanToken) scanToken.cancelled = true;
    const token = { cancelled: false };
    scanToken = token;
    try { return await fn(token); } finally { if (scanToken === token) scanToken = null; }
  };
  handle('fs:findName', ({ q, kind }) => scan((token) => F.searchByName(roots(), { q: String(q || ''), kind, token })));
  handle('fs:findInside', ({ q }) => scan((token) => F.searchContent(roots(), { q: String(q || ''), token })));
  handle('fs:cancelScan', () => { if (scanToken) scanToken.cancelled = true; return true; });
  handle('fs:readEditable', (p) => F.readEditable(roots(), p));
  handle('fs:write', ({ path: p, text }) => F.writeText(roots(), p, text));
  handle('fs:restoreBackup', (p) => F.restoreBackup(roots(), p));
  handle('fs:analyze', (p) => analyzeFile(roots(), p));

  // AI edits a text/code/CSV/JSON file. In "apply" mode it is written directly (a .nova-bak backup is always made first).
  handle('fs:aiEdit', async ({ path: p, instruction, mode }) => {
    const original = await F.readEditable(roots(), p);
    const sys = `You are a careful file editor. Apply the user's instruction to the file '${path.basename(p)}'. ` +
      'Reply with ONLY the complete updated file content: no explanations and no code fences.';
    const out = await providers.chat(providerConfig(), [
      { role: 'system', content: sys },
      { role: 'user', content: `Instruction: ${instruction}\n\nFILE CONTENT:\n${original}` },
    ]);
    const proposal = stripFence(out);
    if ((mode || store.getSettings().aiEditMode) === 'apply') {
      const bad = FE.validateContent(p, proposal);
      if (bad) return { applied: false, original, proposal, warning: bad };
      const { backup } = await F.writeText(roots(), p, proposal.endsWith('\n') ? proposal : proposal + '\n');
      return { applied: true, backup, original, proposal };
    }
    return { applied: false, original, proposal };
  });

  // PDF / Office document -> AI rewrite -> NEW PDF next to the original (the original is never touched).
  handle('fs:pdfRewrite', async ({ path: p, instruction }) => {
    const src = await F.readForAI(roots(), p, { maxChars: 60000 });
    if (!src.text) throw new Error('This document has no extractable text (it may be a scanned image).');
    const sys = 'You transform documents. Apply the user\'s instruction to the document and reply with ONLY the resulting document text (plain text, no commentary).';
    const out = await providers.chat(providerConfig(), [
      { role: 'system', content: sys }, { role: 'user', content: `Instruction: ${instruction}\n\nDOCUMENT:\n${src.text}` }]);
    const dest = F.uniqueSibling(p, 'edited', '.pdf');
    F.assertInside(roots(), dest);
    const res = await createPdf({ title: path.basename(p, path.extname(p)) + ' (edited)', text: out, outPath: dest });
    return { ...res, truncated: src.truncated };
  });

  handle('fs:planSort', async ({ folder, mode, onlyImages }) => {
    const plan = await F.planSort(roots(), folder, { mode, onlyImages: Boolean(onlyImages) });
    return plan.map((x) => ({ name: path.basename(x.from), to: path.basename(x.toDir) }));
  });
  handle('fs:applySort', async ({ folder, mode, onlyImages }) => {
    const plan = await F.planSort(roots(), folder, { mode, onlyImages: Boolean(onlyImages) });
    return F.applySort(roots(), plan, store.journalFile);
  });
  handle('fs:undoSort', () => F.undoLastSort(roots(), store.journalFile));
  handle('fs:reveal', (p) => {
    if (!createdPaths.has(p)) F.assertInside(allowedImageRoots(), p);
    shell.showItemInFolder(p);
    return true;
  });

  // Export an AI answer to a file (format chosen by the extension the user picks).
  handle('export:save', async ({ title, text, format }) => {
    const fmt = ['pdf', 'docx', 'txt', 'md', 'html', 'csv', 'json', 'py', 'js'].includes(format) ? format : 'pdf';
    const r = await dialog.showSaveDialog(win, {
      title: 'Export', defaultPath: path.join(app.getPath('documents'), `NOVA-${Date.now()}.${fmt}`),
      filters: [
        { name: 'PDF', extensions: ['pdf'] }, { name: 'Word document', extensions: ['docx'] }, { name: 'Text', extensions: ['txt'] },
        { name: 'Markdown', extensions: ['md'] }, { name: 'HTML', extensions: ['html'] }, { name: 'CSV', extensions: ['csv'] },
        { name: 'JSON', extensions: ['json'] }, { name: 'Python', extensions: ['py'] }, { name: 'JavaScript', extensions: ['js'] },
        { name: 'Other source/text file', extensions: ['ts', 'java', 'kt', 'c', 'cpp', 'cs', 'go', 'rs', 'sh', 'sql', 'xml', 'yml', 'yaml', 'css'] },
      ],
    });
    if (r.canceled || !r.filePath) return null;
    const res = await exportToPath(r.filePath, { title: String(title || ''), text: String(text || '') });
    createdPaths.add(r.filePath);
    return res;
  });

  // ---- images
  handle('image:generate', async ({ prompt }) => {
    const img = await imageGen.generate(imageCfg(), String(prompt || ''));
    const file = path.join(dirOf('generated'), `img_${Date.now()}.${img.ext}`);
    fs.writeFileSync(file, img.bytes);
    return { path: file };
  });
  handle('image:test', async (cfg = {}) => imageGen.test(imageCfg({
    backend: cfg.backend, url: cfg.url, model: cfg.model, cloudUrl: cfg.cloudUrl || store.getSettings().baseUrl,
    apiKey: cfg.apiKey && cfg.apiKey.trim() ? cfg.apiKey.trim() : store.getApiKey(),
  })));
  handle('image:read', (p) => {
    F.assertInside(allowedImageRoots(), p);
    const img = nativeImage.createFromPath(p);
    if (img.isEmpty()) {
      const mime = { webp: 'image/webp', gif: 'image/gif', bmp: 'image/bmp', svg: 'image/svg+xml' }[extOf(p)];
      if (!mime || fs.statSync(p).size > 8_000_000) throw new Error('This image cannot be previewed.');
      return `data:${mime};base64,` + fs.readFileSync(p).toString('base64');
    }
    const out = img.getSize().width > 900 ? img.resize({ width: 900, quality: 'good' }) : img;
    return 'data:image/jpeg;base64,' + out.toJPEG(88).toString('base64');
  });
  handle('image:saveAs', async (p) => {
    F.assertInside(allowedImageRoots(), p);
    const e = extOf(p) || 'png';
    const r = await dialog.showSaveDialog(win, { title: 'Save image', defaultPath: path.join(app.getPath('pictures'), 'NOVA-' + path.basename(p)), filters: [{ name: 'Image', extensions: [e] }] });
    if (r.canceled || !r.filePath) return null;
    fs.copyFileSync(p, r.filePath);
    createdPaths.add(r.filePath);
    return { path: r.filePath };
  });
  handle('image:analyze', async ({ path: p, mode }) => {
    F.assertInside(allowedImageRoots(), p);
    const prompt = ANALYSIS_PROMPTS[mode] || ANALYSIS_PROMPTS.describe;
    return chatWithHint(configFor(true), [{ role: 'user', content: prompt, images: [visionB64(p)] }], {}, true);
  });
  // Resize in place (with backup) or convert to a new PNG/JPEG file next to the original.
  handle('image:op', async ({ path: p, op, width, format }) => {
    F.assertInside(roots(), p);
    const img = nativeImage.createFromPath(p);
    if (img.isEmpty()) throw new Error('Only PNG and JPEG images can be edited here.');
    const enc = (im, e) => (e === 'png' ? im.toPNG() : im.toJPEG(92));
    if (op === 'resize') {
      const w = Math.round(Number(width));
      if (!(w >= 16 && w <= 8000)) throw new Error('Enter a width between 16 and 8000 pixels.');
      const e = extOf(p) === 'png' ? 'png' : 'jpg';
      fs.copyFileSync(p, p + '.nova-bak');
      fs.writeFileSync(p, enc(img.resize({ width: w, quality: 'best' }), e));
      return { path: p, backup: p + '.nova-bak', size: img.resize({ width: w }).getSize() };
    }
    if (op === 'convert') {
      const e = format === 'png' ? 'png' : 'jpg';
      const dest = F.uniqueDest(path.dirname(p), path.basename(p, path.extname(p)) + '.' + e);
      F.assertInside(roots(), dest);
      fs.writeFileSync(dest, enc(img, e));
      return { path: dest };
    }
    throw new Error('Unknown image operation.');
  });

  // ---- overlay (bubble + quick-assist panel)
  handle('overlay:toggle', () => { overlay.togglePanel(); return true; });
  handle('overlay:hide', () => { overlay.hidePanel(); return true; });
  handle('overlay:quit', () => { quitApp(); return true; });
  handle('capture:list', () => overlay.listSources());
  handle('capture:take', async ({ sourceId } = {}) => {
    const shot = await overlay.capture(sourceId || null);
    const big = shot.getSize().width > 1600 ? shot.resize({ width: 1600, quality: 'good' }) : shot;
    const file = path.join(dirOf('captures'), `screen_${Date.now()}.jpg`);
    fs.writeFileSync(file, big.toJPEG(85));
    const small = big.resize({ width: 640, quality: 'good' });
    return { path: file, dataUrl: 'data:image/jpeg;base64,' + small.toJPEG(70).toString('base64') };
  });
  handle('overlay:ask', async ({ text, imagePath }) => {
    const s = store.getSettings();
    const msgs = [];
    if (s.systemPrompt && s.systemPrompt.trim()) msgs.push({ role: 'system', content: s.systemPrompt.trim() });
    const m = { role: 'user', content: String(text || '') };
    if (imagePath) { F.assertInside([dirOf('captures')], imagePath); m.images = [visionB64(imagePath)]; }
    msgs.push(m);
    return { reply: await chatWithHint(configFor(Boolean(imagePath)), msgs, {}, Boolean(imagePath)) };
  });
  handle('overlay:openMain', ({ text, imagePath, reply } = {}) => {
    if (text) {
      const now = Date.now();
      const conv = store.saveConversation({
        title: String(text).slice(0, 40),
        messages: [
          { role: 'user', content: String(text), images: imagePath ? [{ path: imagePath }] : [], ts: now },
          ...(reply ? [{ role: 'assistant', content: String(reply), ts: now }] : []),
        ],
      });
      showMain();
      const send = () => win.webContents.send('open-conv', conv.id);
      if (win.webContents.isLoading()) win.webContents.once('did-finish-load', send); else send();
    } else showMain();
    overlay.hidePanel();
    return true;
  });
}

app.whenReady().then(() => {
  store = new Store(app.getPath('userData'), safeStorage);
  overlay = createOverlayController({ onOpenMain: showMain, onQuit: quitApp });
  register();
  cleanOldCaptures();
  createWindow();
  if (store.getSettings().overlayEnabled) overlay.start();
  app.on('activate', showMain);
});
app.on('before-quit', () => { quitting = true; });
app.on('second-instance', showMain);
app.on('window-all-closed', () => { if (process.platform !== 'darwin' && (!overlay || !overlay.isRunning())) app.quit(); });
