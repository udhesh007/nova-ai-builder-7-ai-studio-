'use strict';
const $ = (id) => document.getElementById(id);
const call = (ch, arg) => window.novaOverlay.invoke(ch, arg).then((r) => { if (!r.ok) throw new Error(r.error); return r.data; });
let shot = null;   // { path, dataUrl }
let lastReply = ''; let lastQuestion = '';
let busy = false;

const setStatus = (t) => { $('status').textContent = t || ''; };

async function loadSources() {
  try {
    const list = await call('capture:list');
    const sel = $('source');
    const cur = sel.value;
    sel.replaceChildren(new Option('Entire screen', ''));
    list.filter((s) => s.type === 'window').forEach((s) => sel.append(new Option('Window: ' + s.name.slice(0, 40), s.id)));
    sel.value = [...sel.options].some((o) => o.value === cur) ? cur : '';
  } catch (e) { setStatus(e.message); }
}

async function capture() {
  if (busy) return;
  busy = true; $('capture').disabled = true; setStatus('Capturing…');
  try {
    shot = await call('capture:take', { sourceId: $('source').value || null });
    $('shot').src = shot.dataUrl;
    ['shot', 'chips', 'clearShot'].forEach((id) => $(id).classList.remove('hidden'));
    setStatus('Captured. Pick an action or type a question.');
  } catch (e) { setStatus(e.message); } finally { busy = false; $('capture').disabled = false; }
}

function clearShot() {
  shot = null; $('shot').removeAttribute('src');
  ['shot', 'chips', 'clearShot'].forEach((id) => $(id).classList.add('hidden'));
}

async function ask(text) {
  const q = (text || $('q').value).trim();
  if (!q && !shot) return;
  if (busy) return;
  busy = true; $('ask').disabled = true; setStatus(shot ? 'Sending the screenshot to your AI…' : 'Asking…');
  $('out').textContent = ''; $('outActions').classList.add('hidden');
  try {
    lastQuestion = q || 'What is on this screen?';
    lastReply = (await call('overlay:ask', { text: lastQuestion, imagePath: shot ? shot.path : null })).reply;
    $('out').textContent = lastReply; $('outActions').classList.remove('hidden'); setStatus('');
  } catch (e) { $('out').textContent = ''; setStatus('✗ ' + e.message); } finally { busy = false; $('ask').disabled = false; }
}

$('capture').addEventListener('click', capture);
$('clearShot').addEventListener('click', clearShot);
$('refresh').addEventListener('click', loadSources);
$('ask').addEventListener('click', () => ask());
$('q').addEventListener('keydown', (e) => { if (e.key === 'Enter') ask(); });
document.querySelectorAll('#chips button').forEach((b) => b.addEventListener('click', () => ask(b.dataset.q)));
$('close').addEventListener('click', () => call('overlay:hide'));
$('openMain').addEventListener('click', () => call('overlay:openMain', {}));
$('copy').addEventListener('click', () => navigator.clipboard.writeText(lastReply).then(() => setStatus('Copied.')));
$('continue').addEventListener('click', () => call('overlay:openMain', { text: lastQuestion, imagePath: shot ? shot.path : null, reply: lastReply }));
window.addEventListener('keydown', (e) => { if (e.key === 'Escape') call('overlay:hide'); });
loadSources();
