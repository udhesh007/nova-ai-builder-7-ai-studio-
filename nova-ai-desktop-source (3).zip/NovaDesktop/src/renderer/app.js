'use strict';
// NOVA AI Desktop - renderer. All model output is rendered with textContent (never innerHTML).

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function el(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    e.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return e;
}

async function call(channel, ...args) {
  const r = await window.nova.invoke(channel, ...args);
  if (!r.ok) throw new Error(r.error);
  return r.data;
}

let toastTimer;
function toast(msg, ms = 4500) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), ms);
}

// prompt() is not available in Electron, so use small dialogs instead.
function askDialog(title, buildInput, getValue) {
  return new Promise((resolve) => {
    const input = buildInput();
    const dlg = el('dialog', { class: 'small-dialog' }, el('b', { text: title }), input,
      el('div', { class: 'row' },
        el('button', { class: 'ghost', onclick: () => { dlg.close(); resolve(null); } }, 'Cancel'),
        el('button', { class: 'primary', onclick: () => { dlg.close(); resolve(getValue(input) || null); } }, 'OK')));
    dlg.addEventListener('close', () => { dlg.remove(); resolve(null); });
    document.body.append(dlg);
    dlg.showModal();
    input.focus();
  });
}
const askText = (title, initial = '') => askDialog(title, () => el('input', { type: 'text', value: initial }), (i) => i.value.trim());
const askChoice = (title, options) => askDialog(title, () => el('select', {}, options.map(([v, l]) => el('option', { value: v }, l))), (i) => i.value);

const fmtSize = (n) => (n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB');
const fmtDate = (ms) => new Date(ms).toLocaleDateString();
const extOf = (p) => (p.includes('.') ? p.split('.').pop().toLowerCase() : '');
const TEXT_EXT = new Set(['txt', 'md', 'csv', 'tsv', 'json', 'xml', 'html', 'htm', 'css', 'js', 'ts', 'jsx', 'tsx', 'py', 'java', 'kt', 'c', 'cpp', 'h', 'cs', 'go', 'rs', 'rb', 'php', 'sh', 'bat', 'ps1', 'sql', 'yml', 'yaml', 'toml', 'ini', 'cfg', 'log', 'tex', 'gradle', 'properties', 'rtf']);
const OFFICE = new Set(['docx', 'pptx', 'xlsx']);
const VISION_IMG = new Set(['png', 'jpg', 'jpeg']);
const isText = (p) => TEXT_EXT.has(extOf(p));
const READABLE = (p) => isText(p) || extOf(p) === 'pdf' || OFFICE.has(extOf(p)) || VISION_IMG.has(extOf(p));
const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/openai/';

const state = {
  s: null, hasKey: false, secure: true, version: '', sep: '/',
  conv: { id: null, title: 'New chat', messages: [] },
  convs: [], attachments: [], busy: false, requestId: null,
  browseDir: null, organizeFolder: '',
};

// ---------------------------------------------------------------- navigation
function showView(name) {
  $$('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + name));
  $$('.nav').forEach((b) => b.classList.toggle('active', b.dataset.view === name));
  if (name === 'files') renderFiles();
  if (name === 'settings') renderSettings();
}
$$('.nav').forEach((b) => b.addEventListener('click', () => showView(b.dataset.view)));

function configured() {
  const s = state.s;
  if (!s) return false;
  return s.provider === 'cloud' ? Boolean(s.baseUrl && s.model && state.hasKey) : Boolean(s.host && s.port && s.localModel);
}

async function refreshSettings() {
  const d = await call('settings:get');
  Object.assign(state, { s: d.settings, hasKey: d.hasKey, secure: d.secure, version: d.version, sep: d.sep });
  renderBanner();
}

function renderBanner() {
  const b = $('#banner');
  b.classList.toggle('hidden', configured());
  b.replaceChildren(
    el('b', { text: 'No AI provider configured. ' }),
    'NOVA AI does not generate replies by itself. Connect Google Gemini (free tier), another cloud API, or a local Ollama model. ',
    el('button', { class: 'primary', onclick: () => showView('settings') }, 'Open Settings'));
}

// ---------------------------------------------------------------- images
const imgCache = new Map();
const loadImg = (p) => { if (!imgCache.has(p)) imgCache.set(p, call('image:read', p)); return imgCache.get(p); };
function imageEl(p, cls = 'msg-img') {
  const img = el('img', { class: cls, alt: 'Image' });
  loadImg(p).then((src) => { img.src = src; }).catch(() => { imgCache.delete(p); img.replaceWith(el('span', { class: 'muted small', text: '(image no longer available)' })); });
  return img;
}

// ---------------------------------------------------------------- chat rendering
function renderText(container, text) {
  text.split('```').forEach((part, i) => {
    if (i % 2 === 1) {
      const nl = part.indexOf('\n');
      const first = nl >= 0 ? part.slice(0, nl).trim() : '';
      const code = nl >= 0 && first.length <= 20 && !first.includes(' ') ? part.slice(nl + 1) : part;
      container.append(el('pre', {}, el('code', { text: code.trimEnd() })));
    } else if (part.trim()) {
      container.append(el('p', { text: part.trim() }));
    }
  });
}

function editItems(edits) {
  return el('div', { class: 'edits' }, edits.map((e) => e.ok
    ? el('div', { class: 'edit-item' }, '✓ Edited ' + e.path.split(/[\\/]/).pop() + ' (backup kept as .nova-bak)',
      el('button', { onclick: async () => { try { await call('fs:restoreBackup', e.path); toast('Restored the previous version of ' + e.path.split(/[\\/]/).pop()); } catch (err) { toast(err.message); } } }, 'Undo'),
      el('button', { onclick: () => call('fs:reveal', e.path).catch((err) => toast(err.message)) }, 'Show'))
    : el('div', { class: 'edit-item' }, '✗ ' + e.path.split(/[\\/]/).pop() + ': ' + e.error)));
}

function renderMessages() {
  const box = $('#messages');
  box.replaceChildren();
  const msgs = state.conv.messages;
  if (!msgs.length) {
    const ex = ['Summarize a PDF from my documents', 'Find the invoice that mentions "total due" and tell me the amount', 'Fix the syntax error in my script and save it', '/image a glowing blue jellyfish in deep space'];
    box.append(el('div', { class: 'welcome' },
      el('div', { class: 'logo', text: 'N' }), el('h2', { text: 'Hello, I’m NOVA' }),
      el('p', { class: 'muted', text: 'Add folders in “Files & PDFs” so I can search, read, edit and organize your documents. The floating N button (top-right of your screen) lets you capture the screen and ask about it. Try:' }),
      ex.map((t) => el('button', { onclick: () => { $('#input').value = t; $('#input').focus(); } }, t))));
  }
  msgs.forEach((m, i) => {
    const d = el('div', { class: 'msg ' + m.role + (m.error ? ' error' : '') });
    if (m.attachments && m.attachments.length) d.append(el('div', { class: 'chips' }, m.attachments.map((a) => el('span', { class: 'chip', text: '📎 ' + a.name }))));
    (m.images || []).forEach((im) => d.append(imageEl(im.path)));
    renderText(d, m.content);
    if (m.edits && m.edits.length) d.append(editItems(m.edits));
    const last = i === msgs.length - 1 && !state.busy;
    if (m.role === 'assistant' && !m.error) {
      const hasImg = (m.images || []).length > 0;
      d.append(el('div', { class: 'msg-actions' },
        el('button', { onclick: () => { navigator.clipboard.writeText(m.content).then(() => toast('Copied')); } }, '📋 Copy'),
        hasImg ? el('button', { onclick: async () => { try { const r = await call('image:saveAs', m.images[0].path); if (r) toast('Image saved.'); } catch (e) { toast(e.message); } } }, '💾 Save image…') : null,
        !hasImg ? el('button', { onclick: () => exportMessage(m, 'pdf') }, '📄 PDF') : null,
        !hasImg ? el('button', { onclick: () => exportMessage(m) }, '💾 Export…') : null,
        last && !hasImg ? el('button', { onclick: retry }, '↻ Retry') : null));
    } else if (m.error && last) {
      d.append(el('div', { class: 'msg-actions' }, el('button', { onclick: retry }, '↻ Retry')));
    }
    box.append(d);
  });
  if (state.busy) box.append(el('div', { class: 'msg assistant thinking', text: 'NOVA is working…' }));
  box.scrollTop = box.scrollHeight;
  $('#sendBtn').textContent = state.busy ? '■ Stop' : 'Send';
}

function renderAttachments() {
  $('#attachRow').replaceChildren(...state.attachments.map((a, i) =>
    el('span', { class: 'chip' }, '📎 ' + a.name, el('button', { title: 'Remove', onclick: () => { state.attachments.splice(i, 1); renderAttachments(); } }, '✕'))));
  const canEdit = state.attachments.some((a) => isText(a.path));
  $('#editRow').classList.toggle('hidden', !canEdit);
  if (!canEdit) $('#allowEdits').checked = false;
}

async function saveConv() {
  const c = state.conv;
  if (!c.messages.length) return;
  if (!c.title || c.title === 'New chat') c.title = (c.messages.find((m) => m.role === 'user')?.content || 'Chat').slice(0, 40);
  try { state.conv = await call('conv:save', c); } catch { /* history is best-effort */ }
  await loadConvList();
}

async function loadConvList() {
  try { state.convs = await call('conv:list'); } catch { state.convs = []; }
  $('#convList').replaceChildren(...state.convs.map((c) => el('div', { class: 'conv' + (c.id === state.conv.id ? ' active' : ''), onclick: () => openConv(c.id) },
    el('span', { class: 't', text: c.title }),
    el('button', { title: 'Rename', onclick: async (e) => { e.stopPropagation(); const t = await askText('Rename chat', c.title); if (t) { await call('conv:rename', { id: c.id, title: t }); loadConvList(); } } }, '✎'),
    el('button', { title: 'Delete', onclick: async (e) => { e.stopPropagation(); if (confirm('Delete this chat?')) { await call('conv:delete', c.id); if (state.conv.id === c.id) newChat(); else loadConvList(); } } }, '🗑'))));
}

async function openConv(id) {
  if (state.busy) return;
  const c = await call('conv:get', id);
  if (c) { state.conv = c; state.attachments = []; renderAttachments(); renderMessages(); loadConvList(); showView('chat'); }
}

function newChat() {
  if (state.busy) return;
  state.conv = { id: null, title: 'New chat', messages: [] };
  state.attachments = [];
  renderAttachments(); renderMessages(); loadConvList(); showView('chat');
}

async function generate(opts = {}) {
  state.busy = true;
  state.requestId = crypto.randomUUID();
  renderMessages();
  try {
    const { reply, edits } = await call('chat:send', { requestId: state.requestId, messages: state.conv.messages, allowEdits: Boolean(opts.allowEdits) });
    state.conv.messages.push({ role: 'assistant', content: reply, edits: edits && edits.length ? edits : undefined, ts: Date.now() });
  } catch (e) {
    if (e.message !== 'Cancelled.') state.conv.messages.push({ role: 'assistant', content: e.message, error: true, ts: Date.now() });
  } finally {
    state.busy = false;
    renderMessages();
    saveConv();
  }
}

async function generateImage(prompt) {
  state.busy = true;
  renderMessages();
  try {
    const { path } = await call('image:generate', { prompt });
    state.conv.messages.push({ role: 'assistant', content: 'Image for: ' + prompt, images: [{ path }], ts: Date.now() });
  } catch (e) {
    state.conv.messages.push({ role: 'assistant', content: e.message, error: true, ts: Date.now() });
  } finally {
    state.busy = false;
    renderMessages();
    saveConv();
  }
}

async function send() {
  if (state.busy) { call('chat:cancel', state.requestId); return; }
  const text = $('#input').value.trim();
  if (!text && !state.attachments.length) return;
  const isImageCmd = /^\/image(\s|$)/i.test(text);
  if (isImageCmd) {
    const prompt = text.replace(/^\/image\s*/i, '').trim();
    if (!prompt) { toast('Describe the picture, e.g. /image a red fox in snow'); return; }
    if (!state.s || state.s.imageBackend === 'none') { toast('Choose an image backend in Settings first.'); showView('settings'); return; }
    state.conv.messages.push({ role: 'user', content: text, ts: Date.now() });
    $('#input').value = '';
    generateImage(prompt);
    return;
  }
  if (!configured()) { toast('Set up an AI provider in Settings first.'); showView('settings'); return; }
  const allowEdits = $('#allowEdits').checked && state.attachments.some((a) => isText(a.path));
  state.conv.messages.push({ role: 'user', content: text || 'Please summarize the attached file(s).', attachments: state.attachments, ts: Date.now() });
  state.attachments = [];
  $('#input').value = '';
  renderAttachments();
  generate({ allowEdits });
}

function retry() {
  if (state.busy) return;
  const msgs = state.conv.messages;
  if (msgs.length && msgs[msgs.length - 1].role === 'assistant') msgs.pop();
  const lastUser = [...msgs].reverse().find((m) => m.role === 'user');
  if (lastUser && /^\/image(\s|$)/i.test(lastUser.content)) generateImage(lastUser.content.replace(/^\/image\s*/i, '').trim());
  else generate();
}

async function exportMessage(m, format) {
  const title = (m.content.split('\n').find((l) => l.trim()) || 'NOVA AI').replace(/^[#*\s]+/, '').slice(0, 60);
  let fmt = format;
  if (!fmt) {
    fmt = await askChoice('Export as…', [['pdf', 'PDF'], ['docx', 'Word document (.docx)'], ['md', 'Markdown'], ['txt', 'Plain text'], ['html', 'HTML'], ['csv', 'CSV'], ['json', 'JSON'], ['py', 'Python file (code block only)'], ['js', 'JavaScript file (code block only)']]);
    if (!fmt) return;
  }
  try {
    const r = await call('export:save', { title, text: m.content, format: fmt });
    if (!r) return;
    let note = 'Saved: ' + r.path;
    if (r.replacedChars) note += ` (${r.replacedChars} unsupported character(s) replaced with “?”; no Unicode font found)`;
    toast(note, 7000);
    call('fs:reveal', r.path).catch(() => {});
  } catch (e) { toast('Could not export: ' + e.message); }
}

$('#sendBtn').addEventListener('click', send);
$('#input').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
$('#newChat').addEventListener('click', newChat);

function attachFile(f) {
  if (!state.attachments.some((a) => a.path === f.path)) state.attachments.push({ path: f.path, name: f.name });
  renderAttachments();
  showView('chat');
  $('#input').focus();
  toast(`Attached ${f.name}. Ask your question and press Send.`);
}

// ---------------------------------------------------------------- analysis dialog
async function openAnalysis(f) {
  const dlg = $('#analysis');
  $('#analysisTitle').textContent = f.name;
  $('#analysisReport').textContent = 'Analyzing…';
  $('#analysisOut').textContent = '';
  $('#analysisActions').replaceChildren();
  $('#analysisImg').classList.add('hidden');
  dlg.showModal();
  const out = $('#analysisOut');
  const actions = $('#analysisActions');
  const e = extOf(f.path);
  try {
    if (VISION_IMG.has(e)) {
      $('#analysisReport').textContent = `Image: ${f.name}\nSize: ${fmtSize(f.size)}\nPath: ${f.path}\n\nObject detection and text extraction use your configured vision model (local if it is an Ollama vision model such as llava).`;
      loadImg(f.path).then((src) => { const im = $('#analysisImg'); im.src = src; im.classList.remove('hidden'); }).catch(() => {});
      for (const [mode, label] of [['objects', '🔎 Detect objects'], ['ocr', '🔤 Extract text (OCR)'], ['describe', '📝 Describe']]) {
        actions.append(el('button', { onclick: async () => {
          if (!configured()) { out.textContent = 'Set up an AI provider in Settings first.'; return; }
          out.textContent = 'Asking the vision model…';
          try { out.textContent = await call('image:analyze', { path: f.path, mode }); } catch (err) { out.textContent = err.message; }
        } }, label));
      }
      actions.append(el('button', { onclick: () => { $('#analysis').close(); attachFile(f); } }, '💬 Ask AI about it'));
      return;
    }
    const a = await call('fs:analyze', f.path);
    $('#analysisReport').textContent = a.report + (a.preview ? '\n\n--- Preview ---\n' + a.preview : '');
    if (READABLE(f.path)) actions.append(el('button', { onclick: () => { $('#analysis').close(); attachFile(f); } }, '💬 Ask AI about it'));
    if (a.diagnostics && a.diagnostics.length && isText(f.path)) {
      actions.append(el('button', { class: 'primary', onclick: async () => {
        if (!configured()) { out.textContent = 'Set up an AI provider in Settings first.'; return; }
        out.textContent = 'Asking the AI to fix the problems…';
        try {
          const instr = 'Fix these problems without changing anything else:\n' + a.diagnostics.map((d) => `${d.line ? 'line ' + d.line + ': ' : ''}${d.message}`).join('\n');
          const r = await call('fs:aiEdit', { path: f.path, instruction: instr });
          out.textContent = r.applied ? `Fixed and saved. The previous version is kept as ${f.name}.nova-bak (use Edit → Restore backup to undo).`
            : (r.warning ? 'The AI’s proposal was not applied: ' + r.warning : 'Review mode: open Edit to see the proposal.') + '\n\n' + r.proposal.slice(0, 3000);
        } catch (err) { out.textContent = err.message; }
      } }, '🛠 Fix with AI'));
    }
  } catch (err) { $('#analysisReport').textContent = err.message; }
}
$('#analysisClose').addEventListener('click', () => $('#analysis').close());

// ---------------------------------------------------------------- files
function fileRow(f, { snippet } = {}) {
  const e = extOf(f.path);
  const analyzable = READABLE(f.path);
  return el('div', { class: 'item' },
    el('div', { class: 'name' }, el('b', { text: f.name }), el('span', { text: snippet || `${f.path}  ·  ${fmtSize(f.size)}  ·  ${fmtDate(f.mtime)}` })),
    el('div', { class: 'actions' },
      analyzable ? el('button', { onclick: () => attachFile(f) }, '💬 Ask AI') : null,
      analyzable ? el('button', { onclick: () => openAnalysis(f) }, '🔍 Analyze') : null,
      isText(f.path) ? el('button', { onclick: () => openEditor(f) }, '✎ Edit') : null,
      e === 'pdf' || OFFICE.has(e) ? el('button', { title: 'Creates a NEW PDF; the original is never changed', onclick: () => rewriteToPdf(f) }, '✨ Rewrite → PDF') : null,
      VISION_IMG.has(e) ? el('button', { onclick: () => resizeImage(f) }, 'Resize') : null,
      VISION_IMG.has(e) ? el('button', { onclick: () => convertImage(f) }, 'Convert') : null,
      el('button', { onclick: () => call('fs:reveal', f.path).catch((err) => toast(err.message)) }, 'Show')));
}

async function rewriteToPdf(f) {
  if (!configured()) { toast('Set up an AI provider in Settings first.'); return; }
  const instr = await askText('What should the AI do? (e.g. summarize in 10 bullets, translate to English)', '');
  if (!instr) return;
  toast('Working… this can take a minute.', 60000);
  try {
    const r = await call('fs:pdfRewrite', { path: f.path, instruction: instr });
    toast('Created ' + r.path.split(/[\\/]/).pop() + ' next to the original.' + (r.replacedChars ? ` (${r.replacedChars} unsupported character(s) replaced)` : ''), 7000);
    call('fs:reveal', r.path).catch(() => {});
  } catch (e) { toast(e.message); }
}
async function resizeImage(f) {
  const w = await askText('New width in pixels (the original is backed up as .nova-bak)', '1280');
  if (!w) return;
  try { const r = await call('image:op', { path: f.path, op: 'resize', width: Number(w) }); toast('Resized. Backup: ' + r.backup.split(/[\\/]/).pop()); } catch (e) { toast(e.message); }
}
async function convertImage(f) {
  const fmt = await askChoice('Convert to…', [['png', 'PNG'], ['jpg', 'JPEG']]);
  if (!fmt) return;
  try { const r = await call('image:op', { path: f.path, op: 'convert', format: fmt }); toast('Created ' + r.path.split(/[\\/]/).pop()); } catch (e) { toast(e.message); }
}

function renderFiles() {
  const fp = $('#foldersPanel');
  const folders = state.s.folders;
  fp.replaceChildren(
    el('b', { text: 'Folders NOVA AI may use' }),
    el('p', { class: 'muted small', text: 'NOVA only reads or changes files inside these folders, when you press a button or ask it to. It never uploads files by itself and never deletes files; edits always keep a .nova-bak backup. File text is sent to your AI provider only when you attach a file, use Ask AI, or let the AI edit it.' }),
    folders.length ? el('div', { class: 'list' }, folders.map((f) => el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', { text: f })),
      el('button', { onclick: async () => { state.s.folders = await call('folders:remove', f); state.browseDir = null; renderFiles(); } }, 'Remove')))) : el('p', { class: 'muted', text: 'No folders yet.' }),
    el('div', { class: 'row' }, el('button', { class: 'primary', onclick: async () => { try { const r = await call('folders:add'); if (r) { state.s.folders = r; renderFiles(); } } catch (e) { toast(e.message); } } }, '+ Add folder')));
  renderBrowse(); renderFind(); renderInside(); renderOrganize();
}

$$('.tab').forEach((t) => t.addEventListener('click', () => {
  $$('.tab').forEach((x) => x.classList.toggle('active', x === t));
  $$('.tabview').forEach((v) => v.classList.toggle('active', v.id === 'tab-' + t.dataset.tab));
}));

async function renderBrowse() {
  const box = $('#tab-browse');
  const folders = state.s.folders;
  if (!folders.length) { box.replaceChildren(el('p', { class: 'muted', text: 'Add a folder first.' })); return; }
  if (!state.browseDir || !folders.some((f) => state.browseDir === f || state.browseDir.startsWith(f + state.sep))) state.browseDir = null;
  if (!state.browseDir) {
    box.replaceChildren(el('div', { class: 'list' }, folders.map((f) => el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', { text: '📁 ' + f })), el('button', { onclick: () => { state.browseDir = f; renderBrowse(); } }, 'Open')))));
    return;
  }
  try {
    const items = await call('fs:list', state.browseDir);
    const isRoot = folders.includes(state.browseDir);
    const parent = state.browseDir.slice(0, state.browseDir.lastIndexOf(state.sep)) || state.sep;
    box.replaceChildren(
      el('div', { class: 'row' },
        el('button', { onclick: () => { state.browseDir = isRoot ? null : parent; renderBrowse(); } }, '← Up'),
        el('span', { class: 'muted', text: state.browseDir }),
        el('button', { onclick: () => { state.organizeFolder = state.browseDir; renderOrganize(); $$('.tab').find((t) => t.dataset.tab === 'organize').click(); } }, 'Organize this folder…')),
      el('div', { class: 'list' }, items.length ? items.map((f) => f.isDir
        ? el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', { text: '📁 ' + f.name })), el('button', { onclick: () => { state.browseDir = f.path; renderBrowse(); } }, 'Open'))
        : fileRow(f)) : [el('div', { class: 'item muted', text: 'Empty folder' })]));
  } catch (e) { box.replaceChildren(el('p', { class: 'muted', text: e.message })); }
}

function searchTab(boxId, build) {
  const box = $(boxId);
  const results = el('div');
  const status = el('p', { class: 'muted small' });
  box.replaceChildren(...build(results, status));
}

function renderFind() {
  searchTab('#tab-find', (results, status) => {
    const q = el('input', { type: 'text', placeholder: 'File name contains… (leave empty to list a type)' });
    const kind = el('select', {}, el('option', { value: 'all' }, 'All files'), el('option', { value: 'pdf' }, 'PDFs'), el('option', { value: 'docs' }, 'Documents'), el('option', { value: 'images' }, 'Images'));
    const go = async () => {
      status.textContent = 'Searching…'; results.replaceChildren();
      try {
        const items = await call('fs:findName', { q: q.value, kind: kind.value });
        status.textContent = `${items.length} result(s)` + (items.length >= 300 ? ' (showing the first 300)' : '');
        results.replaceChildren(el('div', { class: 'list' }, items.map((f) => fileRow(f))));
      } catch (e) { status.textContent = e.message; }
    };
    q.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    return [el('div', { class: 'row' }, q, kind, el('button', { class: 'primary', onclick: go }, 'Search')), status, results];
  });
}

function renderInside() {
  searchTab('#tab-inside', (results, status) => {
    const q = el('input', { type: 'text', placeholder: 'Text to find inside documents…' });
    const go = async () => {
      status.textContent = 'Searching inside files (PDF and Office files can take a while)…'; results.replaceChildren();
      try {
        const r = await call('fs:findInside', { q: q.value });
        status.textContent = `${r.items.length} file(s). Scanned ${r.scannedPdfs} PDF/Office file(s)` + (r.skippedPdfs ? `, skipped ${r.skippedPdfs} (limit)` : '') + '. Scanned/image-only PDFs have no searchable text.';
        results.replaceChildren(el('div', { class: 'list' }, r.items.map((f) => fileRow(f, { snippet: '…' + f.snippet + '…' }))));
      } catch (e) { status.textContent = e.message; }
    };
    q.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    return [el('p', { class: 'muted small', text: 'Searches text inside PDFs, Word (.docx), PowerPoint (.pptx), Excel (.xlsx), notes, code, CSV and JSON files.' }),
      el('div', { class: 'row' }, q, el('button', { class: 'primary', onclick: go }, 'Search'), el('button', { onclick: () => call('fs:cancelScan') }, 'Stop')), status, results];
  });
}

function renderOrganize() {
  searchTab('#tab-organize', (results, status) => {
    const folders = state.s.folders;
    if (!folders.length) return [el('p', { class: 'muted', text: 'Add a folder first.' })];
    const folder = el('input', { type: 'text', value: state.organizeFolder || folders[0] });
    const pick = el('select', { onchange: () => { folder.value = pick.value; } }, folders.map((f) => el('option', { value: f }, f)));
    const mode = el('select', {}, el('option', { value: 'type' }, 'By type (Images, PDFs, Documents…)'), el('option', { value: 'month' }, 'By month modified'), el('option', { value: 'ext' }, 'By file extension'));
    const onlyImg = el('input', { type: 'checkbox' });
    const args = () => ({ folder: folder.value.trim(), mode: mode.value, onlyImages: onlyImg.checked });
    const apply = el('button', { class: 'primary hidden' }, 'Move files');
    const preview = async () => {
      results.replaceChildren(); apply.classList.add('hidden');
      try {
        const plan = await call('fs:planSort', args());
        if (!plan.length) { status.textContent = 'No files to move directly inside this folder.'; return; }
        const groups = {};
        plan.forEach((p) => { (groups[p.to] = groups[p.to] || []).push(p.name); });
        status.textContent = `${plan.length} file(s) would be moved (sub-folders are created inside the chosen folder). Nothing is deleted or overwritten.`;
        results.replaceChildren(el('div', { class: 'list' }, Object.entries(groups).map(([to, names]) => el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', { text: to + '/  (' + names.length + ')' }), el('span', { text: names.slice(0, 6).join(', ') + (names.length > 6 ? '…' : '') }))))));
        apply.classList.remove('hidden');
      } catch (e) { status.textContent = e.message; }
    };
    apply.addEventListener('click', async () => {
      if (!confirm('Move these files into sub-folders now? You can undo the last organize afterwards.')) return;
      try {
        const r = await call('fs:applySort', args());
        status.textContent = `Moved ${r.moved} file(s)` + (r.failed ? `, ${r.failed} failed` : '') + '. You can undo this.';
        results.replaceChildren(); apply.classList.add('hidden');
      } catch (e) { status.textContent = e.message; }
    });
    const undo = el('button', { onclick: async () => {
      if (!confirm('Move the files from the last organize back to where they were?')) return;
      try { const r = await call('fs:undoSort'); status.textContent = `Restored ${r.restored} file(s)` + (r.skipped ? `, skipped ${r.skipped}` : '') + '.'; } catch (e) { status.textContent = e.message; }
    } }, '↶ Undo last organize');
    return [el('p', { class: 'muted small', text: 'Sorts the files directly inside a folder (not sub-folders) into sub-folders. Preview first; nothing moves until you confirm.' }),
      el('div', { class: 'row' }, folder, pick), el('div', { class: 'row' }, mode, el('label', {}, onlyImg, ' only images')),
      el('div', { class: 'row' }, el('button', { onclick: preview }, 'Preview'), apply, undo), status, results];
  });
}

// ---------------------------------------------------------------- editor
let editing = null;
async function openEditor(f) {
  try {
    const text = await call('fs:readEditable', f.path);
    editing = { path: f.path, original: text };
    $('#editorTitle').textContent = f.name;
    $('#editorText').value = text;
    $('#editorInstr').value = '';
    $('#editorMsg').textContent = '';
    $('#editor').showModal();
  } catch (e) { toast(e.message); }
}
$('#editorClose').addEventListener('click', () => $('#editor').close());
$('#editorRevert').addEventListener('click', () => { $('#editorText').value = editing.original; $('#editorMsg').textContent = 'Reverted to the text on disk.'; });
$('#editorUndo').addEventListener('click', async () => {
  try {
    await call('fs:restoreBackup', editing.path);
    const t = await call('fs:readEditable', editing.path);
    editing.original = t; $('#editorText').value = t;
    $('#editorMsg').textContent = 'Restored the version from the .nova-bak backup (click again to switch back).';
  } catch (e) { $('#editorMsg').textContent = e.message; }
});
$('#editorAsk').addEventListener('click', async () => {
  const instr = $('#editorInstr').value.trim();
  if (!instr) return;
  if (!configured()) { toast('Set up an AI provider in Settings first.'); return; }
  $('#editorMsg').textContent = 'Asking the AI…';
  $('#editorAsk').disabled = true;
  try {
    // Save any manual changes first so the AI edits what you see.
    if ($('#editorText').value !== editing.original) {
      await call('fs:write', { path: editing.path, text: $('#editorText').value });
      editing.original = $('#editorText').value;
    }
    const r = await call('fs:aiEdit', { path: editing.path, instruction: instr });
    $('#editorText').value = r.proposal;
    if (r.applied) { editing.original = r.proposal; $('#editorMsg').textContent = 'AI edit applied and saved. The previous version is kept as .nova-bak (use “Restore backup” to undo).'; }
    else if (r.warning) $('#editorMsg').textContent = 'Not saved: ' + r.warning + ' Review the text below.';
    else $('#editorMsg').textContent = r.original && r.proposal.length < r.original.length / 2 ? 'AI proposal loaded, but it is much shorter than the original. Review carefully, then Save.' : 'AI proposal loaded. Review it, then Save.';
  } catch (e) { $('#editorMsg').textContent = e.message; } finally { $('#editorAsk').disabled = false; }
});
$('#editorSave').addEventListener('click', async () => {
  const text = $('#editorText').value;
  if (text === editing.original) { $('#editorMsg').textContent = 'No changes to save.'; return; }
  if (!confirm('Overwrite this file? The previous version is kept as a .nova-bak copy.')) return;
  try {
    await call('fs:write', { path: editing.path, text });
    editing.original = text;
    $('#editorMsg').textContent = 'Saved. Backup kept next to the file (.nova-bak).';
  } catch (e) { $('#editorMsg').textContent = e.message; }
});

// ---------------------------------------------------------------- settings
function field(label, input, hint) {
  return el('div', { class: 'field' }, el('label', { text: label }), input, hint ? el('div', { class: 'muted small', text: hint }) : null);
}

function renderSettings() {
  const s = state.s;
  const box = $('#settingsForm');
  const providerSel = el('select', {}, el('option', { value: 'gemini' }, 'Google Gemini (cloud, free tier available)'), el('option', { value: 'custom' }, 'Other cloud API (OpenAI-compatible)'), el('option', { value: 'local' }, 'Ollama (local: http://localhost:11434)'));
  providerSel.value = s.provider === 'local' ? 'local' : s.cloudPreset === 'gemini' ? 'gemini' : 'custom';
  const baseUrl = el('input', { type: 'text', value: s.baseUrl, placeholder: 'https://…/v1' });
  const key = el('input', { type: 'password', placeholder: state.hasKey ? 'Key saved (leave empty to keep it)' : 'Paste your API key' });
  const model = el('input', { type: 'text', value: s.model, placeholder: 'model name from your provider', list: 'cloudModels' });
  const cloudModels = el('datalist', { id: 'cloudModels' });
  const host = el('input', { type: 'text', value: s.host });
  const port = el('input', { type: 'text', value: s.port });
  const localModel = el('input', { type: 'text', value: s.localModel, placeholder: 'a model shown by “ollama list”', list: 'models' });
  const datalist = el('datalist', { id: 'models' });
  const timeout = el('input', { type: 'number', value: s.timeoutSec, min: 5, max: 300 });
  const sys = el('textarea', { rows: 3, placeholder: 'Optional: how NOVA should behave' });
  sys.value = s.systemPrompt;
  const visionModel = el('input', { type: 'text', value: s.visionModel, placeholder: 'e.g. qwen2.5vl:3b (leave empty to use the main model)', list: 'models' });
  const editMode = el('select', {}, el('option', { value: 'apply' }, 'Apply AI edits directly (a .nova-bak backup is always made first)'), el('option', { value: 'review' }, 'Show me the AI’s proposal and let me Save'));
  editMode.value = s.aiEditMode;
  const result = el('p', { class: 'small' });

  const geminiNote = el('p', { class: 'muted small', text: 'Gemini has a free tier (no card). Create a key in Google AI Studio, paste it below, then tap “List models” and pick a current Flash or Flash-Lite model. Google says free-tier content may be used to improve its products: avoid confidential data. Screen/image questions need a vision-capable model (Gemini Flash models are).' });
  const cloudBox = el('div', {}, geminiNote,
    field('API base URL (https only)', baseUrl),
    field('API key', key, state.secure ? 'Stored encrypted with your operating system’s secure storage.' : 'Secure storage is unavailable: the key is kept in memory for this session only.'),
    field('Model identifier', model),
    el('button', { onclick: async () => {
      try { const names = await call('provider:cloudModels', { baseUrl: providerSel.value === 'gemini' ? GEMINI_URL : baseUrl.value, apiKey: key.value }); cloudModels.replaceChildren(...names.map((n) => el('option', { value: n }))); result.textContent = names.length ? 'Models you can use: ' + names.slice(0, 40).join(', ') : 'Connected, but no models were listed.'; } catch (e) { result.textContent = '✗ ' + e.message; }
    } }, 'List models'), cloudModels);
  const localBox = el('div', {},
    el('p', { class: 'muted small', text: 'Install Ollama (ollama.com), run “ollama pull <model>”. localhost:11434 is the default. For image questions pull a vision model (for example llava). To use another computer on your Wi-Fi, start Ollama there with OLLAMA_HOST=0.0.0.0, allow it through the firewall for private networks only, and enter its IP. Never expose it to the internet.' }),
    field('Host', host), field('Port', port), field('Model name', localModel),
    el('button', { onclick: async () => { try { const names = await call('provider:models', { host: host.value.trim(), port: port.value.trim() }); datalist.replaceChildren(...names.map((n) => el('option', { value: n }))); result.textContent = names.length ? 'Installed models: ' + names.join(', ') : 'Connected, but no models are installed.'; } catch (e) { result.textContent = '✗ ' + e.message; } } }, 'List installed models'), datalist);
  const sync = () => {
    const local = providerSel.value === 'local';
    cloudBox.classList.toggle('hidden', local); localBox.classList.toggle('hidden', !local);
    geminiNote.classList.toggle('hidden', providerSel.value !== 'gemini');
    if (providerSel.value === 'gemini') { baseUrl.value = GEMINI_URL; baseUrl.setAttribute('readonly', ''); } else baseUrl.removeAttribute('readonly');
  };
  providerSel.addEventListener('change', sync); sync();

  // image generation
  const imgBackend = el('select', {}, el('option', { value: 'none' }, 'Off'), el('option', { value: 'a1111' }, 'Automatic1111 / SD WebUI / Forge / SD.Next (local)'), el('option', { value: 'invokeai' }, 'InvokeAI (connection check only)'), el('option', { value: 'openai' }, 'OpenAI-compatible images API (uses the cloud settings above)'));
  imgBackend.value = s.imageBackend;
  const imgUrl = el('input', { type: 'text', value: s.imageUrl, placeholder: 'http://127.0.0.1:7860' });
  const imgModel = el('input', { type: 'text', value: s.imageModel, placeholder: 'image model identifier' });
  const imgSteps = el('input', { type: 'number', value: s.imageSteps, min: 1, max: 150 });
  const imgW = el('input', { type: 'number', value: s.imageWidth, min: 64, max: 2048, step: 64 });
  const imgH = el('input', { type: 'number', value: s.imageHeight, min: 64, max: 2048, step: 64 });
  const imgNeg = el('input', { type: 'text', value: s.imageNegative, placeholder: 'e.g. blurry, low quality' });
  const imgResult = el('p', { class: 'small' });
  const imgLocal = el('div', {}, field('Server URL', imgUrl, 'Automatic1111 default: http://127.0.0.1:7860 (start it with --api). InvokeAI default: http://127.0.0.1:9090.'),
    field('Steps', imgSteps), field('Width × Height', el('div', { class: 'row' }, imgW, imgH)), field('Negative prompt (optional)', imgNeg));
  const imgOpenai = el('div', {}, field('Image model identifier', imgModel, 'Must be an image-generation model your provider supports. Free tiers often do not include image models.'));
  const imgSync = () => { imgLocal.classList.toggle('hidden', !['a1111', 'invokeai'].includes(imgBackend.value)); imgOpenai.classList.toggle('hidden', imgBackend.value !== 'openai'); };
  imgBackend.addEventListener('change', imgSync); imgSync();

  const collect = () => {
    const local = providerSel.value === 'local';
    return {
      provider: local ? 'local' : 'cloud', cloudPreset: providerSel.value === 'gemini' ? 'gemini' : 'custom',
      baseUrl: providerSel.value === 'gemini' ? GEMINI_URL : baseUrl.value, model: model.value, host: host.value, port: port.value, localModel: localModel.value,
      timeoutSec: timeout.value, systemPrompt: sys.value, aiEditMode: editMode.value, visionModel: visionModel.value,
      imageBackend: imgBackend.value, imageUrl: imgUrl.value, imageModel: imgModel.value, imageSteps: imgSteps.value, imageWidth: imgW.value, imageHeight: imgH.value, imageNegative: imgNeg.value,
    };
  };
  const test = async () => {
    const c = collect();
    result.textContent = 'Testing…';
    try {
      result.textContent = '✓ ' + await call('provider:test', { kind: c.provider, baseUrl: c.baseUrl, apiKey: key.value, model: c.provider === 'cloud' ? c.model : c.localModel, timeoutSec: Number(c.timeoutSec), host: c.host, port: c.port });
    } catch (e) { result.textContent = '✗ ' + e.message; }
  };
  const save = async () => {
    try {
      const r = await call('settings:save', { settings: collect(), apiKey: key.value });
      key.value = '';
      await refreshSettings();
      toast('Settings saved.' + (r.persisted ? '' : ' (API key kept in memory only — secure storage is unavailable.)'));
      renderSettings();
    } catch (e) { result.textContent = '✗ ' + e.message; }
  };

  const overlayBox = el('input', { type: 'checkbox' });
  overlayBox.checked = s.overlayEnabled;
  overlayBox.addEventListener('change', async () => {
    try { await call('settings:save', { settings: { overlayEnabled: overlayBox.checked } }); state.s.overlayEnabled = overlayBox.checked; toast(overlayBox.checked ? 'Floating button is on.' : 'Floating button is off.'); } catch (e) { toast(e.message); }
  });

  box.replaceChildren(
    el('div', { class: 'card' }, el('h3', { text: 'AI provider' }), field('Provider', providerSel), cloudBox, localBox,
      field('Request timeout (seconds, 5–300)', timeout), field('Custom instructions (optional)', sys),
      field('Vision model (for screenshots, OCR and images)', visionModel, 'Text-only models such as qwen2.5 cannot read images. Set a vision model here and NOVA uses it automatically whenever an image is involved, while text chats keep using your main model. For Ollama: run “ollama pull qwen2.5vl:3b” (about 3 GB, needs about 5 GB RAM; “minicpm-v” is also good at OCR), then click “List installed models” above. With Gemini, use a Flash model for everything. The Image generation settings below are NOT needed for OCR.'),
      field('When the AI edits a file', editMode, 'Edits only touch text, code, CSV and JSON files inside folders you granted. JSON is validated before it is written.'),
      el('div', { class: 'row' }, el('button', { class: 'primary', onclick: save }, 'Save settings'), el('button', { onclick: test }, 'Test connection'),
        el('button', { onclick: async () => { if (confirm('Delete the stored API key?')) { await call('settings:deleteKey'); await refreshSettings(); renderSettings(); toast('API key deleted'); } } }, 'Delete stored API key')), result),
    el('div', { class: 'card' }, el('h3', { text: 'Floating button & screen capture' }),
      el('label', {}, overlayBox, ' Show the floating “N” button at the top-right of my screen (always on top)'),
      el('p', { class: 'muted small', text: 'Click it to open a quick panel: capture the whole screen or one window, ask a question, extract text (OCR) or find an error. The screenshot is sent to your AI provider only when you press an action; it is hidden while capturing and stored privately in the app data folder (deleted after 14 days). With the button on, closing the main window keeps NOVA running — use the tray icon or the panel to quit. macOS asks for Screen Recording permission the first time; on Linux/Wayland the system asks you to approve sharing.' })),
    el('div', { class: 'card' }, el('h3', { text: 'Image generation' }), field('Backend', imgBackend), imgLocal, imgOpenai,
      el('div', { class: 'row' }, el('button', { class: 'primary', onclick: save }, 'Save settings'), el('button', { onclick: async () => {
        imgResult.textContent = 'Testing…';
        try { imgResult.textContent = '✓ ' + await call('image:test', { backend: imgBackend.value, url: imgUrl.value, model: imgModel.value, cloudUrl: providerSel.value === 'gemini' ? GEMINI_URL : baseUrl.value, apiKey: key.value }); } catch (e) { imgResult.textContent = '✗ ' + e.message; }
      } }, 'Test image backend')), imgResult,
      el('p', { class: 'muted small', text: 'Type /image followed by a description in the chat. InvokeAI generation is not supported yet (only the connection check); use an Automatic1111-compatible server, or an OpenAI-compatible images API.' })),
    el('div', { class: 'card' }, el('h3', { text: 'Privacy' }),
      el('p', { class: 'small', text: 'Conversations are stored on this computer only. With a cloud provider, your messages — and the text of files or images you attach, analyze or let the AI edit — are sent over HTTPS to the URL you configured; your key is sent only there. With Ollama, the same content goes to the host you entered (unencrypted http on your network). Local image servers receive only your prompt. NOVA never deletes files, never uploads files on its own, and always makes a .nova-bak backup before changing a file.' }),
      el('div', { class: 'row' }, el('button', { onclick: async () => { if (confirm('Delete ALL chat history?')) { await call('conv:clear'); newChat(); toast('History cleared'); } } }, 'Clear all chat history'))),
    el('div', { class: 'card' }, el('h3', { text: 'About' }), el('p', { class: 'small', text: `NOVA AI Desktop ${state.version}` })));
}

// ---------------------------------------------------------------- start
(async function init() {
  try { await refreshSettings(); } catch (e) { toast('Could not load settings: ' + e.message); }
  if (window.nova.onOpenConversation) window.nova.onOpenConversation((id) => { openConv(id).then(() => loadConvList()); });
  renderMessages();
  renderAttachments();
  loadConvList();
})();
