'use strict';
// Settings and conversation storage (JSON files in the app's data folder).
// The API key is encrypted with the operating system's secure storage (Electron safeStorage).
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULTS = {
  provider: 'cloud', // 'cloud' | 'local'
  baseUrl: '', model: '', timeoutSec: 60, systemPrompt: '',
  host: '127.0.0.1', port: '11434', localModel: '',
  folders: [],
  visionModel: '', // optional separate model used when a message contains an image (screenshots, OCR)
  cloudPreset: 'custom', // 'gemini' | 'custom'
  overlayEnabled: true,
  aiEditMode: 'apply',   // 'apply' (write directly, backup always made) | 'review' (show proposal first)
  imageBackend: 'none',  // 'none' | 'a1111' | 'invokeai' | 'openai'
  imageUrl: 'http://127.0.0.1:7860', imageModel: '', imageSteps: 20, imageWidth: 512, imageHeight: 512, imageNegative: '',
};

class Store {
  constructor(dir, safeStorage) {
    this.dir = dir;
    this.safe = safeStorage;
    this.sessionKey = ''; // used only when secure storage is unavailable
    fs.mkdirSync(dir, { recursive: true });
    this.settingsFile = path.join(dir, 'settings.json');
    this.keyFile = path.join(dir, 'apikey.bin');
    this.convFile = path.join(dir, 'conversations.json');
    this.journalFile = path.join(dir, 'last-sort.json');
  }

  _read(file, fallback) {
    try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
  }
  _write(file, data) {
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data), 'utf8');
    fs.renameSync(tmp, file);
  }

  getSettings() { return { ...DEFAULTS, ...this._read(this.settingsFile, {}) }; }
  saveSettings(patch) {
    const s = { ...this.getSettings(), ...patch };
    this._write(this.settingsFile, s);
    return s;
  }

  secureAvailable() { return Boolean(this.safe && this.safe.isEncryptionAvailable()); }
  setApiKey(key) {
    if (!key) return this.deleteApiKey();
    if (this.secureAvailable()) {
      fs.writeFileSync(this.keyFile, this.safe.encryptString(key));
      this.sessionKey = '';
      return { persisted: true };
    }
    this.sessionKey = key;
    return { persisted: false };
  }
  getApiKey() {
    if (this.sessionKey) return this.sessionKey;
    try { return this.safe.decryptString(fs.readFileSync(this.keyFile)); } catch { return ''; }
  }
  hasApiKey() { return Boolean(this.sessionKey) || fs.existsSync(this.keyFile); }
  deleteApiKey() {
    this.sessionKey = '';
    try { fs.unlinkSync(this.keyFile); } catch { /* none stored */ }
    return { persisted: false };
  }

  // ---- conversations: { id, title, createdAt, updatedAt, messages: [{role, content, attachments, error, ts}] }
  listConversations() {
    return this._read(this.convFile, []).map(({ id, title, updatedAt }) => ({ id, title, updatedAt }))
      .sort((a, b) => b.updatedAt - a.updatedAt);
  }
  getConversation(id) { return this._read(this.convFile, []).find((c) => c.id === id) || null; }
  saveConversation(conv) {
    const all = this._read(this.convFile, []);
    const c = { ...conv, id: conv.id || crypto.randomUUID(), updatedAt: Date.now(), createdAt: conv.createdAt || Date.now() };
    const i = all.findIndex((x) => x.id === c.id);
    if (i >= 0) all[i] = c; else all.push(c);
    this._write(this.convFile, all);
    return c;
  }
  renameConversation(id, title) {
    const all = this._read(this.convFile, []);
    const c = all.find((x) => x.id === id);
    if (c) { c.title = String(title).slice(0, 80); this._write(this.convFile, all); }
  }
  deleteConversation(id) { this._write(this.convFile, this._read(this.convFile, []).filter((c) => c.id !== id)); }
  clearConversations() { this._write(this.convFile, []); }
}

module.exports = { Store, DEFAULTS };
