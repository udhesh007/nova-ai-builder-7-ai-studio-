'use strict';
const fs = require('fs');

async function extractPdfText(buffer, { maxChars = 300000, maxPages = 800 } = {}) {
  const pdfjs = require('pdfjs-dist/legacy/build/pdf.js');
  const doc = await pdfjs.getDocument({
    data: new Uint8Array(buffer), useSystemFonts: true, isEvalSupported: false, disableFontFace: true, verbosity: 0,
  }).promise;
  try {
    const pages = Math.min(doc.numPages, maxPages);
    let out = '';
    for (let i = 1; i <= pages; i++) {
      const page = await doc.getPage(i);
      const tc = await page.getTextContent();
      out += tc.items.map((it) => (it.str || '') + (it.hasEOL ? '\n' : '')).join('') + '\n\n';
      if (out.length >= maxChars) break;
    }
    return {
      text: out.slice(0, maxChars).trim(),
      truncated: out.length > maxChars || pages < doc.numPages,
      pages: doc.numPages,
    };
  } finally {
    await doc.destroy();
  }
}

const UNICODE_FONTS = [
  'C:\\Windows\\Fonts\\arial.ttf', 'C:\\Windows\\Fonts\\segoeui.ttf', 'C:\\Windows\\Fonts\\Nirmala.ttf',
  '/System/Library/Fonts/Supplemental/Arial Unicode.ttf', '/Library/Fonts/Arial Unicode.ttf',
  '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf',
  '/usr/share/fonts/TTF/DejaVuSans.ttf',
];
function findUnicodeFont() {
  return UNICODE_FONTS.find((p) => { try { return fs.statSync(p).isFile(); } catch { return false; } }) || null;
}

/** Creates a simple text PDF. Resolves to { path, usedUnicodeFont, replacedChars }. */
function createPdf({ title, text, outPath, fontPath }) {
  const PDFDocument = require('pdfkit');
  return new Promise((resolve, reject) => {
    const needsUnicode = /[^\x00-\xff]/.test(title + text);
    const uni = needsUnicode ? (fontPath === undefined ? findUnicodeFont() : fontPath) : null;
    let replacedChars = 0;
    const clean = (s) => (needsUnicode && !uni ? s.replace(/[^\x00-\xff]/g, () => { replacedChars++; return '?'; }) : s);

    const doc = new PDFDocument({ size: 'A4', margin: 50, info: { Title: clean(title || 'NOVA AI') } });
    const out = fs.createWriteStream(outPath);
    out.on('error', reject);
    out.on('finish', () => resolve({ path: outPath, usedUnicodeFont: Boolean(uni), replacedChars }));
    doc.on('error', reject);
    doc.pipe(out);

    const body = uni ? uni : 'Helvetica';
    const bold = uni ? uni : 'Helvetica-Bold';
    const mono = 'Courier';
    if (title) { doc.font(bold).fontSize(20).text(clean(title)); doc.moveDown(); }
    clean(text).split('```').forEach((part, i) => {
      if (i % 2 === 1) {
        const code = part.includes('\n') ? part.slice(part.indexOf('\n') + 1) : part;
        doc.font(uni && /[^\x00-\xff]/.test(code) ? uni : mono).fontSize(9.5).text(code.trimEnd());
        doc.moveDown(0.5);
      } else if (part.trim()) {
        doc.font(body).fontSize(11).text(part.trim(), { lineGap: 2 });
        doc.moveDown(0.5);
      }
    });
    doc.end();
  });
}

module.exports = { extractPdfText, createPdf, findUnicodeFont };
