'use strict';
// Local (no AI) syntax / consistency checks for code and data files.
const vm = require('vm');
const path = require('path');
const { execFile } = require('child_process');
const { parseCsv } = require('./docs');

const lineCol = (text, pos) => {
  const before = text.slice(0, pos);
  return { line: before.split('\n').length, column: pos - before.lastIndexOf('\n') };
};

/** Finds the index of the first invalid character in a JSON text (null if valid). */
function jsonErrorPos(t) {
  let i = 0;
  const n = t.length;
  const fail = () => { throw i; };
  const ws = () => { while (i < n && ' \t\n\r'.includes(t[i])) i++; };
  const str = () => {
    i++;
    while (i < n && t[i] !== '"') { if (t[i] === '\\') i++; else if (t[i] < ' ') fail(); i++; }
    if (i >= n) fail();
    i++;
  };
  const val = () => {
    ws();
    const c = t[i];
    if (c === '{') {
      i++; ws();
      if (t[i] === '}') { i++; return; }
      for (;;) {
        ws(); if (t[i] !== '"') fail(); str(); ws(); if (t[i] !== ':') fail(); i++; val(); ws();
        if (t[i] === ',') { i++; continue; }
        if (t[i] === '}') { i++; return; }
        fail();
      }
    } else if (c === '[') {
      i++; ws();
      if (t[i] === ']') { i++; return; }
      for (;;) {
        val(); ws();
        if (t[i] === ',') { i++; continue; }
        if (t[i] === ']') { i++; return; }
        fail();
      }
    } else if (c === '"') str();
    else {
      const m = /^(-?\d+(\.\d+)?([eE][+-]?\d+)?|true|false|null)/.exec(t.slice(i, i + 40));
      if (!m) fail();
      i += m[0].length;
    }
  };
  try { val(); ws(); if (i < n) fail(); return null; } catch (p) { if (typeof p === 'number') return p; throw p; }
}

function checkJson(text) {
  try { JSON.parse(text); return { ok: true, diagnostics: [] }; } catch (e) {
    const m = /position (\d+)/.exec(e.message);
    const pos = m ? Number(m[1]) : jsonErrorPos(text);
    const lc = pos != null ? lineCol(text, Math.min(pos, text.length)) : {};
    const msg = e.message.replace(/ in JSON at position.*/, '').replace(/, ".*" is not valid JSON$/s, '');
    return { ok: false, diagnostics: [{ ...lc, message: msg, severity: 'error' }] };
  }
}

function checkJs(text, file) {
  try { new vm.Script(text, { filename: file }); return { ok: true, diagnostics: [] }; } catch (e) {
    if (/Cannot use import statement|Unexpected token 'export'|Cannot use 'import.meta'/.test(e.message)) {
      return { ok: true, diagnostics: [], note: 'This file uses ES-module syntax, which this quick check cannot validate.' };
    }
    const line = Number(/:(\d+)\n/.exec(String(e.stack))?.[1]) || undefined;
    return { ok: false, diagnostics: [{ line, message: e.message, severity: 'error' }] };
  }
}

function checkCsv(text) {
  const { rows, unclosedQuote, delimiter } = parseCsv(text);
  const diagnostics = [];
  if (unclosedQuote) diagnostics.push({ message: 'A quoted field is never closed.', severity: 'error' });
  const width = rows[0]?.length || 0;
  rows.forEach((r, i) => { if (r.length !== width && diagnostics.length < 25) diagnostics.push({ line: i + 1, message: `Row has ${r.length} column(s) but the header has ${width}.`, severity: 'warning' }); });
  return { ok: !diagnostics.length, diagnostics, note: `${rows.length} row(s), ${width} column(s), delimiter ${JSON.stringify(delimiter)}` };
}

function runPython(text) {
  const code = 'import ast,sys\nsrc=sys.stdin.read()\nast.parse(src, "file")\n';
  const attempt = (bin) => new Promise((resolve) => {
    const child = execFile(bin, ['-c', code], { timeout: 10000, maxBuffer: 200000 }, (err, _out, stderr) => resolve({ err, stderr: String(stderr || '') }));
    child.stdin.on('error', () => {});
    child.stdin.end(text);
  });
  return (async () => {
    for (const bin of ['python3', 'python']) {
      const r = await attempt(bin);
      if (r.err && r.err.code === 'ENOENT') continue;
      if (!r.err) return { ok: true, diagnostics: [] };
      const line = Number(/File "file", line (\d+)/.exec(r.stderr)?.[1]) || undefined;
      const msg = r.stderr.trim().split('\n').filter(Boolean).pop() || 'Syntax error';
      return { ok: false, diagnostics: [{ line, message: msg, severity: 'error' }] };
    }
    return { ok: true, diagnostics: [], note: 'Python was not found on this computer, so Python files cannot be checked locally.' };
  })();
}

async function checkText(file, text) {
  const ext = path.extname(file).slice(1).toLowerCase();
  let r;
  if (ext === 'json') r = checkJson(text);
  else if (['js', 'mjs', 'cjs'].includes(ext)) r = checkJs(text, path.basename(file));
  else if (ext === 'csv' || ext === 'tsv') r = checkCsv(text);
  else if (ext === 'py') r = await runPython(text);
  else r = { ok: true, diagnostics: [], note: `No built-in checker for .${ext || 'this'} files. Use "Ask AI" to review it.` };
  return { language: ext, ...r };
}

function formatDiagnostics(res) {
  if (!res.diagnostics.length) return res.note || 'No problems found.';
  return res.diagnostics.map((d) => `${d.severity === 'warning' ? 'Warning' : 'Error'}${d.line ? ` at line ${d.line}${d.column ? ':' + d.column : ''}` : ''}: ${d.message}`).join('\n');
}

module.exports = { checkText, formatDiagnostics, checkJson, checkJs, checkCsv };
