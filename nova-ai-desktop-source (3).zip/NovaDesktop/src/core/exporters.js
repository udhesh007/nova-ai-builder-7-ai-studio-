'use strict';
// Export AI chat output to files: PDF, Word (.docx), HTML, text, Markdown, CSV, JSON and source-code files.
const fs = require('fs');
const path = require('path');
const { zipSync, strToU8 } = require('fflate');
const { createPdf } = require('./pdf');

const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const CODE_EXT = new Set(['py', 'js', 'ts', 'java', 'kt', 'c', 'cpp', 'cs', 'go', 'rs', 'sh', 'sql', 'xml', 'yml', 'yaml', 'css', 'json', 'csv']);

function createDocx(title, text) {
  const run = (t, { bold, mono, size } = {}) =>
    `<w:r><w:rPr>${mono ? '<w:rFonts w:ascii="Courier New" w:hAnsi="Courier New"/>' : ''}${bold ? '<w:b/>' : ''}${size ? `<w:sz w:val="${size}"/>` : ''}</w:rPr><w:t xml:space="preserve">${esc(t)}</w:t></w:r>`;
  const paras = [];
  if (title) paras.push(`<w:p>${run(title, { bold: true, size: 36 })}</w:p>`);
  text.split('```').forEach((part, i) => {
    if (i % 2 === 1) {
      const code = part.includes('\n') ? part.slice(part.indexOf('\n') + 1) : part;
      code.trimEnd().split('\n').forEach((l) => paras.push(`<w:p>${run(l, { mono: true, size: 20 })}</w:p>`));
    } else part.split('\n').forEach((l) => paras.push(`<w:p>${l ? run(l) : ''}</w:p>`));
  });
  const files = {
    '[Content_Types].xml': strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'),
    '_rels/.rels': strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'),
    'word/document.xml': strToU8(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${paras.join('')}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/></w:sectPr></w:body></w:document>`),
  };
  return Buffer.from(zipSync(files));
}

function firstCodeBlock(text) {
  const parts = text.split('```');
  if (parts.length < 3) return null;
  const p = parts[1];
  const nl = p.indexOf('\n');
  const head = nl >= 0 ? p.slice(0, nl).trim() : '';
  return (nl >= 0 && head.length <= 20 && !head.includes(' ') ? p.slice(nl + 1) : p).trimEnd() + '\n';
}

/** Writes `text` to destPath; the format is chosen by the file extension. Existing files are backed up first. */
async function exportToPath(destPath, { title = '', text = '' }) {
  const ext = path.extname(destPath).slice(1).toLowerCase();
  let backup = null;
  if (fs.existsSync(destPath)) { backup = destPath + '.nova-bak'; fs.copyFileSync(destPath, backup); }
  let result = { path: destPath, kind: ext || 'txt', backup };
  if (ext === 'pdf') Object.assign(result, await createPdf({ title, text, outPath: destPath }));
  else if (ext === 'docx') fs.writeFileSync(destPath, createDocx(title, text));
  else if (ext === 'html' || ext === 'htm') {
    const body = text.split('```').map((p, i) => (i % 2 ? `<pre><code>${esc(p.slice(p.indexOf('\n') + 1))}</code></pre>` : p.trim() ? `<p>${esc(p.trim()).replace(/\n/g, '<br>')}</p>` : '')).join('\n');
    fs.writeFileSync(destPath, `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title></head><body>${title ? `<h1>${esc(title)}</h1>` : ''}\n${body}\n</body></html>`, 'utf8');
  } else if (CODE_EXT.has(ext)) {
    fs.writeFileSync(destPath, firstCodeBlock(text) ?? (text.endsWith('\n') ? text : text + '\n'), 'utf8');
  } else {
    fs.writeFileSync(destPath, text, 'utf8');
  }
  return result;
}

module.exports = { createDocx, exportToPath, firstCodeBlock };
