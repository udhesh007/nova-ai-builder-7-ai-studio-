'use strict';
// Local / cloud image generation backends.
//  - a1111  : Automatic1111 Stable Diffusion WebUI API (also SD.Next, Forge and other /sdapi/v1 servers). Start it with --api.
//  - openai : any OpenAI-compatible /images/generations endpoint (uses your cloud URL + key).
//  - invokeai: connection check only. InvokeAI's generation API is a version-specific workflow graph and is not supported yet.
const { AiError, request, openAiBase } = require('./providers');

function validate(cfg) {
  const b = cfg.backend;
  if (!b || b === 'none') return 'Choose an image backend in Settings first.';
  if (b === 'a1111' || b === 'invokeai') {
    let u;
    try { u = new URL((cfg.url || '').trim()); } catch { return 'Enter a valid image server URL (for example http://127.0.0.1:7860).'; }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return 'The image server URL must start with http:// or https://.';
    if (u.username || u.password) return 'Do not put a user name or password in the URL.';
    return null;
  }
  if (b === 'openai') {
    let u;
    try { u = new URL((cfg.cloudUrl || '').trim()); } catch { return 'Set a valid cloud API base URL in the provider settings first.'; }
    if (u.protocol !== 'https:') return 'The cloud API URL must start with https://.';
    if (!cfg.apiKey || !cfg.apiKey.trim()) return 'Enter your API key in the provider settings first.';
    if (!cfg.model || !cfg.model.trim()) return 'Enter an image model identifier.';
    return null;
  }
  return 'Unknown image backend.';
}

const clampInt = (v, lo, hi, d) => { const n = Math.round(Number(v)); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
const trimUrl = (u) => u.trim().replace(/\/+$/, '');

function decodeImage(b64) {
  const buf = Buffer.from(String(b64).replace(/^data:[^,]+,/, ''), 'base64');
  if (buf.length < 8) throw new AiError('The server returned an invalid image.');
  const png = buf[0] === 0x89 && buf[1] === 0x50;
  const jpg = buf[0] === 0xff && buf[1] === 0xd8;
  const webp = buf.subarray(8, 12).toString() === 'WEBP';
  if (!png && !jpg && !webp) throw new AiError('The server returned data that is not a PNG, JPEG or WebP image.');
  return { bytes: buf, ext: png ? 'png' : jpg ? 'jpg' : 'webp' };
}

async function generate(cfg, prompt, { signal } = {}) {
  const problem = validate(cfg);
  if (problem) throw new AiError(problem);
  if (!prompt || !prompt.trim()) throw new AiError('Describe the image you want.');
  if (cfg.backend === 'invokeai') {
    throw new AiError('InvokeAI image generation is not supported yet in this version. Use an Automatic1111-compatible server (A1111, Forge, SD.Next) or an OpenAI-compatible images API.');
  }
  if (cfg.backend === 'a1111') {
    const body = await request(trimUrl(cfg.url) + '/sdapi/v1/txt2img', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, timeoutSec: 600, signal,
      body: JSON.stringify({
        prompt: prompt.trim(), negative_prompt: cfg.negative || '',
        steps: clampInt(cfg.steps, 1, 150, 20), width: clampInt(cfg.width, 64, 2048, 512), height: clampInt(cfg.height, 64, 2048, 512),
        seed: -1, batch_size: 1,
      }),
    });
    let first;
    try { first = JSON.parse(body).images?.[0]; } catch { throw new AiError('The image server returned a malformed response.'); }
    if (!first) throw new AiError('The image server returned no image.');
    return decodeImage(first);
  }
  // OpenAI-compatible
  const body = await request(openAiBase(cfg.cloudUrl) + '/images/generations', {
    method: 'POST', timeoutSec: 180, signal,
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + cfg.apiKey.trim() },
    body: JSON.stringify({ model: cfg.model.trim(), prompt: prompt.trim(), n: 1 }),
  });
  let d;
  try { d = JSON.parse(body).data?.[0]; } catch { throw new AiError('The provider returned a malformed response.'); }
  if (!d) throw new AiError('The provider returned no image data (does this model support image generation?).');
  if (d.b64_json) return decodeImage(d.b64_json);
  if (d.url) {
    if (!String(d.url).startsWith('https://')) throw new AiError('The provider returned a non-https image link; refusing to download it.');
    // The API key is deliberately NOT sent to the image host.
    const buf = await request(d.url, { binary: true, timeoutSec: 120, signal });
    return decodeImage(buf.toString('base64'));
  }
  throw new AiError('The provider returned no image.');
}

async function test(cfg) {
  const problem = validate(cfg);
  if (problem) throw new AiError(problem);
  if (cfg.backend === 'a1111') {
    const body = await request(trimUrl(cfg.url) + '/sdapi/v1/sd-models', { timeoutSec: 15 });
    let n;
    try { n = JSON.parse(body).length; } catch { throw new AiError('Reachable, but this does not look like an Automatic1111-compatible API. Start it with the --api option.'); }
    return `Connected to an Automatic1111-compatible API (${n} model(s) available).`;
  }
  if (cfg.backend === 'invokeai') {
    const body = await request(trimUrl(cfg.url) + '/api/v1/app/version', { timeoutSec: 15 });
    let v;
    try { v = JSON.parse(body).version; } catch { /* handled below */ }
    if (!v) throw new AiError('Reachable, but this does not look like an InvokeAI server.');
    return `InvokeAI ${v} is reachable. Note: image generation through InvokeAI is not supported yet in this version.`;
  }
  return 'OpenAI-compatible image generation uses your cloud provider settings. Try generating an image to test it.';
}

module.exports = { validate, generate, test, decodeImage };
