'use strict';
const { contextBridge, ipcRenderer } = require('electron');

const ALLOWED = new Set([
  'settings:get', 'settings:save', 'settings:deleteKey', 'provider:test', 'provider:models', 'provider:cloudModels',
  'chat:send', 'chat:cancel',
  'conv:list', 'conv:get', 'conv:save', 'conv:rename', 'conv:delete', 'conv:clear',
  'folders:add', 'folders:remove',
  'fs:list', 'fs:findName', 'fs:findInside', 'fs:cancelScan', 'fs:readEditable', 'fs:write', 'fs:aiEdit',
  'fs:restoreBackup', 'fs:analyze', 'fs:pdfRewrite', 'fs:planSort', 'fs:applySort', 'fs:undoSort', 'fs:reveal',
  'export:save',
  'image:generate', 'image:test', 'image:read', 'image:saveAs', 'image:analyze', 'image:op',
]);

contextBridge.exposeInMainWorld('nova', {
  invoke: (channel, ...args) =>
    ALLOWED.has(channel) ? ipcRenderer.invoke(channel, ...args) : Promise.reject(new Error('Blocked channel')),
  onOpenConversation: (cb) => ipcRenderer.on('open-conv', (_e, id) => cb(id)),
});
