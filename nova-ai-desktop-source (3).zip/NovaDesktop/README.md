# NOVA AI Desktop 1.1 (Windows, macOS, Linux)

A personal AI assistant for your laptop (Electron) with a floating screen-capture button, local file tools,
PDF/Office parsing, image tools and several AI back-ends.

## What's new in 1.1
* **Floating "N" button** (always on top, top-right of the screen). Click it for a quick panel: capture the whole screen
  or one window, ask a question, **Extract text (OCR)**, **Find the error**, **Detect objects**, or "Continue in NOVA".
  Settings has an on/off switch. With the button on, closing the main window keeps NOVA running (tray icon / panel to quit).
* **Direct file editing**: attach text/code/CSV/JSON files in chat and tick "Let the AI edit…", or use Edit -> Ask AI.
  A `.nova-bak` backup is always made first, JSON is validated before writing, and Undo restores the backup.
  Setting: apply directly (default) or review the proposal first.
* **PDF / Word / Excel / PowerPoint**: read, search inside, summarize; "Rewrite -> PDF" creates a NEW PDF (original untouched).
* **Export** any AI answer as PDF, Word (.docx), Markdown, text, HTML, CSV, JSON, or a Python/JS file (code block only).
* **Image tools**: resize (with backup) and convert PNG/JPEG; analyze images with a vision model (objects, OCR, description).
* **Image generation** with `/image <prompt>`: Automatic1111-compatible servers (A1111, Forge, SD.Next) or an
  OpenAI-compatible images API. InvokeAI: connection check only (generation not supported yet).
* **Analysis tools**: local syntax checks (JS, JSON, CSV, Python if installed) with line numbers, "Fix with AI",
  document word counts and structure summaries.
* **Providers**: Google Gemini (cloud, with "List models"), any OpenAI-compatible cloud API, Ollama (localhost:11434).

## IMPORTANT: OCR and screenshots need a VISION model
Text-only models such as **qwen2.5** cannot read images. Keep qwen2.5 for text and set a separate model for images:
Settings -> AI provider -> **Vision model**. For Ollama run, for example, `ollama pull qwen2.5vl:3b`
(about 3 GB, about 5 GB RAM; `minicpm-v` is also good at OCR; newer families such as qwen3-vl exist),
then click "List installed models" and type the name. NOVA uses it automatically whenever an image is involved.
With Gemini, Flash models read images. The "Image generation" settings are NOT needed for OCR.

## Build the installers in the cloud (phone-friendly)
1. Create a NEW GitHub repository.
2. Upload `nova-ai-desktop-source.zip` to the repo root.
3. Create `.github/workflows/build-desktop.yml` with the contents of `build-desktop.yml`, commit.
4. Actions -> "Build NOVA AI Desktop" -> Run workflow (5-10 minutes).
5. Download the artifact for your system (`nova-ai-desktop-windows` / `-mac` / `-linux`), extract the ZIP, install/run.
Local build (Node 22): `npm ci --ignore-scripts && npm test && npx electron-builder --publish never`

## First run
* Windows: unsigned app -> SmartScreen "More info" -> "Run anyway". macOS: right-click -> Open (and allow Screen Recording
  in System Settings when asked). Linux: `chmod +x` the AppImage; if it will not start, run with `--no-sandbox`;
  on Wayland the system asks you to approve screen sharing.
* Settings -> choose a provider -> Save -> Test connection. Files & PDFs -> Add folder.

## What was and was not verified
Verified in the build environment (Linux): 40 unit tests pass (providers incl. images, folder sandboxing, PDF/Word/Excel/PowerPoint
parsing, exports, JS/JSON/CSV/Python checks, image-generation back-ends with mock servers, AI edit protocol and backups);
the real Electron app was exercised with a mock AI server (45 checks): floating button + panel windows, bubble click opens the panel,
real screen capture on a virtual display, screenshot sent to the model, direct edits with backup and undo, invalid JSON refused,
PDF rewrite, image generation/resize/convert/analysis, vision-model routing, Office search, settings pages, turning the button
off/on, blocking of paths outside granted folders. A Linux package was built and launched.
NOT verified: Windows and macOS builds, a real cloud provider (including Gemini), real Ollama models, real Automatic1111,
real OCR quality, the always-on-top button over full-screen apps/games, and use on your own computer.

## Known limitations
* Not code-signed. No auto-update.
* OCR/object detection quality depends entirely on the vision model you choose (there is no built-in OCR engine).
* "Local object detection" means a vision model you run locally (for example via Ollama); no dedicated detector is bundled.
* PDFs: text-based PDFs only (no OCR for scanned PDFs, but you can screenshot/attach pages as images). Editing a PDF creates a new PDF.
* Image editing: PNG/JPEG resize and convert only.
* Non-Latin text in created PDFs needs a suitable system font; otherwise characters are replaced with "?" and you are told.
* Python checks need Python installed. InvokeAI generation is not supported yet.
* Large files are truncated before being sent to the AI (about 60,000 characters per file, 150,000 total).
* The AI can make mistakes: backups are always made, but review important edits.
