'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const { zipSync, strToU8 } = require('fflate');
const P = require('../src/core/providers');
const D = require('../src/core/docs');
const E = require('../src/core/exporters');
const X = require('../src/core/debugTools');
const I = require('../src/core/imageGen');
const FE = require('../src/core/fileEdits');
const F = require('../src/core/fsTools');
const { analyzeFile } = require('../src/core/analyze');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'nova-n-'));
function server(handler) {
  return new Promise((resolve) => {
    const reqs = [];
    const s = http.createServer((req, res) => { let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => { reqs.push({ url: req.url, method: req.method, headers: req.headers, body: b }); handler(req, res, b); }); });
    s.listen(0, '127.0.0.1', () => resolve({ s, reqs, port: s.address().port }));
  });
}
const json = (res, code, o) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');

// ---------------------------------------------------------------- providers: images + model list
test('messages with images are converted for OpenAI and Ollama', () => {
  const m = [{ role: 'user', content: 'what is this', images: ['AAA'] }, { role: 'assistant', content: 'hi' }];
  const o = P.toOpenAiMessages(m);
  assert.equal(o[0].content[1].image_url.url, 'data:image/jpeg;base64,AAA');
  assert.equal(o[1].content, 'hi');
  assert.deepEqual(P.toOllamaMessages(m)[0].images, ['AAA']);
});

test('Ollama chat sends images to the server', async () => {
  const { s, reqs, port } = await server((req, res) => json(res, 200, { message: { content: 'a cat' } }));
  try {
    const cfg = { kind: 'local', host: '127.0.0.1', port: String(port), model: 'llava', timeoutSec: 10 };
    assert.equal(await P.chat(cfg, [{ role: 'user', content: 'describe', images: ['QUJD'] }]), 'a cat');
    assert.deepEqual(JSON.parse(reqs[0].body).messages[0].images, ['QUJD']);
  } finally { s.close(); }
});

test('cloudModelNames strips the models/ prefix (Gemini style)', () => {
  assert.deepEqual(P.cloudModelNames('{"data":[{"id":"models/gemini-x"},{"id":"other"}]}'), ['gemini-x', 'other']);
  assert.throws(() => P.cloudModelNames('nope'), /malformed/);
  assert.equal(P.openAiBase('https://a.test/v1/chat/completions/'), 'https://a.test/v1');
});

// ---------------------------------------------------------------- docs
test('docx export round-trips through the docx parser', () => {
  const buf = E.createDocx('My Title', 'First line\nSecond & <third>\n```py\nprint(1)\n```');
  const text = D.extractDocx(buf);
  assert.match(text, /My Title/);
  assert.match(text, /Second & <third>/);
  assert.match(text, /print\(1\)/);
});

test('pptx and xlsx text extraction', () => {
  const pptx = Buffer.from(zipSync({
    'ppt/slides/slide2.xml': strToU8('<p:sld><a:t>Second</a:t></p:sld>'),
    'ppt/slides/slide1.xml': strToU8('<p:sld><a:t>Hello</a:t><a:t>World &amp; Co</a:t></p:sld>'),
  }));
  assert.equal(D.extractPptx(pptx), '--- Slide 1 ---\nHello\nWorld & Co\n\n--- Slide 2 ---\nSecond');
  const xlsx = Buffer.from(zipSync({
    'xl/workbook.xml': strToU8('<workbook><sheets><sheet name="Budget" sheetId="1"/></sheets></workbook>'),
    'xl/sharedStrings.xml': strToU8('<sst><si><t>Item</t></si><si><t>Rent</t></si></sst>'),
    'xl/worksheets/sheet1.xml': strToU8('<worksheet><sheetData><row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="inlineStr"><is><t>Cost</t></is></c></row><row r="2"><c r="A2" t="s"><v>1</v></c><c r="C2"><v>1200</v></c></row></sheetData></worksheet>'),
  }));
  const t = D.extractXlsx(xlsx);
  assert.match(t, /Sheet: Budget/);
  assert.match(t, /Item\tCost/);
  assert.match(t, /Rent\t\t1200/);
  assert.throws(() => D.extractDocx(Buffer.from(zipSync({ 'x.txt': strToU8('a') }))), /not a valid/i);
});

test('CSV parsing handles quotes, delimiters and ragged rows', () => {
  const r = D.parseCsv('a;b;c\n"x;1";"he said ""hi""";3\n1;2\n');
  assert.equal(r.delimiter, ';');
  assert.deepEqual(r.rows[1], ['x;1', 'he said "hi"', '3']);
  assert.equal(r.rows[2].length, 2);
  assert.equal(D.parseCsv('a,b\n"open,1').unclosedQuote, true);
  assert.match(D.jsonShape({ a: 1, b: [1, 2], c: { d: 'x' } }), /a: number.*b: array\(2\) of number/);
});

// ---------------------------------------------------------------- debug tools
test('code/data checks report line numbers', async () => {
  const js = await X.checkText('a.js', 'const a = 1;\nconst b = ;\n');
  assert.equal(js.ok, false);
  assert.equal(js.diagnostics[0].line, 2);
  assert.equal((await X.checkText('a.js', 'const a = 1;')).ok, true);
  const mod = await X.checkText('m.js', "import x from 'y';\n");
  assert.equal(mod.ok, true);
  assert.match(mod.note, /ES-module/);
  const j = await X.checkText('a.json', '{\n  "a": 1,\n  "b": }\n');
  assert.equal(j.ok, false);
  assert.equal(j.diagnostics[0].line, 3);
  const c = await X.checkText('a.csv', 'a,b\n1,2\n3\n');
  assert.equal(c.ok, false);
  assert.equal(c.diagnostics[0].line, 3);
  const py = await X.checkText('a.py', 'def f(:\n  pass\n');
  if (!/not found/.test(py.note || '')) { assert.equal(py.ok, false); assert.equal(py.diagnostics[0].line, 1); }
  assert.equal((await X.checkText('ok.py', 'print(1)\n')).ok, true);
  assert.match(X.formatDiagnostics(js), /line 2/);
});

// ---------------------------------------------------------------- exporters
test('export chooses the format by extension and backs up existing files', async () => {
  const d = tmp();
  const text = 'Intro text\n```python\nprint("hi")\n```\nOutro';
  const py = await E.exportToPath(path.join(d, 'a.py'), { text });
  assert.equal(fs.readFileSync(py.path, 'utf8'), 'print("hi")\n');
  await E.exportToPath(path.join(d, 'a.md'), { text });
  assert.equal(fs.readFileSync(path.join(d, 'a.md'), 'utf8'), text);
  await E.exportToPath(path.join(d, 'a.html'), { title: 'T<', text });
  assert.match(fs.readFileSync(path.join(d, 'a.html'), 'utf8'), /<h1>T&lt;<\/h1>[\s\S]*<pre><code>print/);
  await E.exportToPath(path.join(d, 'a.docx'), { title: 'Doc', text });
  assert.match(D.extractDocx(fs.readFileSync(path.join(d, 'a.docx'))), /Intro text/);
  const pdf = await E.exportToPath(path.join(d, 'a.pdf'), { title: 'Doc', text });
  assert.ok(fs.statSync(pdf.path).size > 400);
  const again = await E.exportToPath(path.join(d, 'a.py'), { text: '```\nx=2\n```' });
  assert.equal(fs.readFileSync(again.backup, 'utf8'), 'print("hi")\n');
});

// ---------------------------------------------------------------- image generation backends
test('Automatic1111 generation and test', async () => {
  const { s, reqs, port } = await server((req, res) => {
    if (req.url === '/sdapi/v1/sd-models') return json(res, 200, [{ title: 'm1' }, { title: 'm2' }]);
    json(res, 200, { images: [PNG.toString('base64')] });
  });
  try {
    const cfg = { backend: 'a1111', url: `http://127.0.0.1:${port}/`, steps: 12, width: 256, height: 256, negative: 'blurry' };
    assert.match(await I.test(cfg), /2 model/);
    const img = await I.generate(cfg, 'a red fox');
    assert.equal(img.ext, 'png');
    const sent = JSON.parse(reqs.find((r) => r.url === '/sdapi/v1/txt2img').body);
    assert.equal(sent.prompt, 'a red fox');
    assert.equal(sent.steps, 12);
    assert.equal(sent.negative_prompt, 'blurry');
  } finally { s.close(); }
});

test('image backends validate configuration and refuse unsupported paths', async () => {
  assert.ok(I.validate({ backend: 'none' }));
  assert.ok(I.validate({ backend: 'a1111', url: 'ftp://x' }));
  assert.ok(I.validate({ backend: 'a1111', url: 'http://u:p@x' }));
  assert.ok(I.validate({ backend: 'openai', cloudUrl: 'http://x', apiKey: 'k', model: 'm' }));
  assert.equal(I.validate({ backend: 'openai', cloudUrl: 'https://x/v1', apiKey: 'k', model: 'm' }), null);
  await assert.rejects(I.generate({ backend: 'invokeai', url: 'http://127.0.0.1:9' }, 'x'), /not supported yet/);
  assert.throws(() => I.decodeImage(Buffer.from('not an image at all').toString('base64')), /not a PNG/);
});

test('InvokeAI connection check', async () => {
  const { s, port } = await server((req, res) => json(res, 200, { version: '5.1.0' }));
  try { assert.match(await I.test({ backend: 'invokeai', url: `http://127.0.0.1:${port}` }), /5\.1\.0.*not supported/); } finally { s.close(); }
});

// ---------------------------------------------------------------- AI file edits (chat protocol)
test('edit blocks are parsed, validated, backed up and restricted to attached files', async () => {
  const root = tmp(); const other = tmp();
  const a = path.join(fs.realpathSync(root), 'a.txt'); fs.writeFileSync(a, 'old');
  const j = path.join(fs.realpathSync(root), 'd.json'); fs.writeFileSync(j, '{"a":1}');
  const evil = path.join(fs.realpathSync(other), 'x.txt'); fs.writeFileSync(evil, 'keep');
  const reply = `Done.\n<<<NOVA_EDIT path="${a}">>>\nnew text\n<<<END_EDIT>>>\n<<<NOVA_EDIT path="${j}">>>\n{broken\n<<<END_EDIT>>>\n<<<NOVA_EDIT path="${evil}">>>\nhacked\n<<<END_EDIT>>>`;
  const blocks = FE.parseEditBlocks(reply);
  assert.equal(blocks.length, 3);
  const res = await FE.applyEdits([root], [a, j], blocks);
  assert.equal(res[0].ok, true);
  assert.equal(fs.readFileSync(a, 'utf8'), 'new text\n');
  assert.equal(fs.readFileSync(a + '.nova-bak', 'utf8'), 'old');
  assert.equal(res[1].ok, false); assert.match(res[1].error, /invalid/);
  assert.equal(fs.readFileSync(j, 'utf8'), '{"a":1}');
  assert.equal(res[2].ok, false);
  assert.equal(fs.readFileSync(evil, 'utf8'), 'keep');
  assert.match(FE.stripEditBlocks(reply), /\[Edited a\.txt\]/);
  assert.match(FE.editSystemPrompt([a]), /NOVA_EDIT/);
  assert.equal(FE.validateContent(a, '   ') !== null, true);
});

// ---------------------------------------------------------------- fsTools additions
test('restoreBackup swaps the file with its backup', async () => {
  const root = tmp();
  const p = path.join(fs.realpathSync(root), 'f.txt'); fs.writeFileSync(p, 'v1');
  await F.writeText([root], p, 'v2');
  await F.restoreBackup([root], p);
  assert.equal(fs.readFileSync(p, 'utf8'), 'v1');
  await F.restoreBackup([root], p); // restoring again brings v2 back
  assert.equal(fs.readFileSync(p, 'utf8'), 'v2');
  await assert.rejects(F.restoreBackup([root], path.join(fs.realpathSync(root), 'none.txt')), /no backup/);
});

test('Word/Excel/PowerPoint files are readable and searchable', async () => {
  const root = tmp(); const r = fs.realpathSync(root);
  fs.writeFileSync(path.join(r, 'plan.docx'), E.createDocx('Plan', 'The launch date is Tuesday'));
  const rd = await F.readForAI([root], path.join(r, 'plan.docx'));
  assert.match(rd.text, /launch date/);
  const found = await F.searchContent([root], { q: 'launch date' });
  assert.equal(found.items.length, 1);
  assert.equal(found.items[0].name, 'plan.docx');
});

test('uniqueSibling does not clobber existing files', () => {
  const root = tmp(); const r = fs.realpathSync(root);
  fs.writeFileSync(path.join(r, 'a.edited.pdf'), 'x');
  assert.equal(path.basename(F.uniqueSibling(path.join(r, 'a.pdf'), 'edited')), 'a.edited_1.pdf');
});

test('analyzeFile summarizes documents, data and code', async () => {
  const root = tmp(); const r = fs.realpathSync(root);
  fs.writeFileSync(path.join(r, 'a.json'), '{"name":"x","items":[1,2]}');
  fs.writeFileSync(path.join(r, 'b.js'), 'let = ;');
  fs.writeFileSync(path.join(r, 'c.docx'), E.createDocx('T', 'hello world again'));
  const j = await analyzeFile([root], path.join(r, 'a.json'));
  assert.equal(j.kind, 'data'); assert.match(j.report, /Structure:.*items: array\(2\)/);
  const b = await analyzeFile([root], path.join(r, 'b.js'));
  assert.equal(b.kind, 'code'); assert.equal(b.diagnostics.length, 1);
  const c = await analyzeFile([root], path.join(r, 'c.docx'));
  assert.equal(c.kind, 'document'); assert.match(c.report, /Words/);
  await assert.rejects(analyzeFile([root], path.join(os.tmpdir(), 'zzz.txt')), /outside/);
});
