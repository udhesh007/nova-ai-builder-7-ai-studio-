'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const F = require('../src/core/fsTools');
const { createPdf, extractPdfText } = require('../src/core/pdf');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'nova-'));
const touch = (dir, name, content = 'x') => { const p = path.join(dir, name); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, content); return p; };

test('path safety: inside, outside, traversal, symlink escape', () => {
  const root = tmp(); const other = tmp();
  const inside = touch(root, 'a/b.txt');
  assert.doesNotThrow(() => F.assertInside([root], inside));
  assert.throws(() => F.assertInside([root], path.join(other, 'x.txt')), /outside/);
  assert.throws(() => F.assertInside([root], path.join(root, '..', path.basename(other), 'x.txt')), /outside/);
  assert.throws(() => F.assertInside([root], 'relative/path'), /Invalid/);
  assert.throws(() => F.assertInside([], inside), /No folders/);
  try {
    fs.symlinkSync(other, path.join(root, 'link'), 'dir');
    assert.throws(() => F.assertInside([root], path.join(root, 'link', 'x.txt')), /outside/);
  } catch (e) { if (e.code !== 'EPERM') throw e; }
});

test('searchByName filters by kind and skips hidden folders', async () => {
  const root = tmp();
  touch(root, 'Report-2024.pdf'); touch(root, 'sub/photo.JPG'); touch(root, 'sub/notes.txt'); touch(root, '.hidden/secret.txt');
  const all = await F.searchByName([root], { q: 'o' });
  assert.deepEqual(all.map((x) => x.name).sort(), ['Report-2024.pdf', 'notes.txt', 'photo.JPG']);
  assert.deepEqual((await F.searchByName([root], { kind: 'images' })).map((x) => x.name), ['photo.JPG']);
  assert.deepEqual((await F.searchByName([root], { kind: 'pdf' })).map((x) => x.name), ['Report-2024.pdf']);
});

test('PDF creation, text extraction and search inside PDFs', async () => {
  const root = tmp();
  const out = path.join(root, 'invoice.pdf');
  const r = await createPdf({ title: 'Quarterly Invoice', text: 'Customer: Acme Corp\nTotal due: 1500 dollars\n```js\nconst x = 1;\n```', outPath: out });
  assert.equal(r.replacedChars, 0);
  assert.ok(fs.statSync(out).size > 500);
  const ex = await extractPdfText(fs.readFileSync(out));
  assert.match(ex.text, /Quarterly Invoice/);
  assert.match(ex.text, /Acme Corp/);
  const found = await F.searchContent([root], { q: 'total due' });
  assert.equal(found.items.length, 1);
  assert.equal(found.scannedPdfs, 1);
  const rd = await F.readForAI([root], out);
  assert.match(rd.text, /1500 dollars/);
  assert.match(rd.note, /PDF/);
});

test('non-Latin text without a Unicode font is replaced, and reported', async () => {
  const root = tmp();
  const r = await createPdf({ title: 'T', text: 'Hello \u0BA4', outPath: path.join(root, 'u.pdf'), fontPath: null });
  assert.equal(r.usedUnicodeFont, false);
  assert.equal(r.replacedChars, 1);
});

test('searchContent finds text inside notes and ignores big/unrelated files', async () => {
  const root = tmp();
  touch(root, 'a.md', 'Meeting notes: budget approved on Friday');
  touch(root, 'b.txt', 'nothing relevant');
  const r = await F.searchContent([root], { q: 'BUDGET' });
  assert.deepEqual(r.items.map((x) => x.name), ['a.md']);
  assert.match(r.items[0].snippet, /budget approved/);
});

test('readForAI rejects unsupported types and outside paths', async () => {
  const root = tmp(); const other = tmp();
  const doc = touch(root, 'a.exe'); const out = touch(other, 'x.txt');
  await assert.rejects(F.readForAI([root], doc), /not supported/);
  await assert.rejects(F.readForAI([root], out), /outside/);
});

test('writeText keeps a backup and refuses non-text files', async () => {
  const root = tmp();
  const p = touch(root, 'doc.txt', 'old');
  const r = await F.writeText([root], p, 'new');
  assert.equal(fs.readFileSync(p, 'utf8'), 'new');
  assert.equal(fs.readFileSync(r.backup, 'utf8'), 'old');
  await assert.rejects(F.writeText([root], touch(root, 'x.exe'), 'z'), /plain-text/);
  await assert.rejects(F.writeText([root], path.join(tmp(), 'q.txt'), 'z'), /outside/);
});

test('sort: preview, apply without overwriting, then undo', async () => {
  const root = tmp(); const journal = path.join(tmp(), 'j.json');
  touch(root, 'a.jpg', '1'); touch(root, 'b.pdf', '2'); touch(root, 'c.txt', '3'); touch(root, 'Images/a.jpg', 'existing');
  const plan = await F.planSort([root], root, { mode: 'type' });
  assert.deepEqual(plan.map((p) => path.basename(p.toDir)).sort(), ['Documents', 'Images', 'PDFs']);
  const res = await F.applySort([root], plan, journal);
  assert.equal(res.moved, 3);
  assert.equal(fs.readFileSync(path.join(root, 'Images', 'a.jpg'), 'utf8'), 'existing'); // untouched
  assert.equal(fs.readFileSync(path.join(root, 'Images', 'a_1.jpg'), 'utf8'), '1');
  assert.ok(!fs.existsSync(path.join(root, 'b.pdf')));
  const undo = await F.undoLastSort([root], journal);
  assert.equal(undo.restored, 3);
  assert.equal(fs.readFileSync(path.join(root, 'b.pdf'), 'utf8'), '2');
  await assert.rejects(F.undoLastSort([root], journal), /nothing to undo/);
});

test('sort refuses folders outside the granted roots', async () => {
  const root = tmp(); const other = tmp();
  await assert.rejects(F.planSort([root], other, {}), /outside/);
  const r = await F.applySort([root], [{ from: touch(other, 'z.jpg'), toDir: path.join(other, 'Images') }], path.join(root, 'j.json'));
  assert.equal(r.moved, 0);
  assert.equal(r.failed, 1);
});

test('sort by month and onlyImages', async () => {
  const root = tmp();
  const a = touch(root, 'a.png'); touch(root, 'b.txt');
  fs.utimesSync(a, new Date('2023-11-15T12:00:00Z'), new Date('2023-11-15T12:00:00Z'));
  const plan = await F.planSort([root], root, { mode: 'month', onlyImages: true });
  assert.equal(plan.length, 1);
  assert.equal(path.basename(plan[0].toDir), '2023-11');
});
