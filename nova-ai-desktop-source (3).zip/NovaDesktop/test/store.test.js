'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { Store } = require('../src/core/store');

const fakeSafe = {
  isEncryptionAvailable: () => true,
  encryptString: (s) => Buffer.from(s.split('').reverse().join('')),
  decryptString: (b) => b.toString().split('').reverse().join(''),
};
const mk = (safe = fakeSafe) => new Store(fs.mkdtempSync(path.join(os.tmpdir(), 'nova-st-')), safe);

test('settings persist and merge with defaults', () => {
  const s = mk();
  assert.equal(s.getSettings().port, '11434');
  s.saveSettings({ model: 'x', folders: ['/a'] });
  assert.equal(s.getSettings().model, 'x');
  assert.deepEqual(s.getSettings().folders, ['/a']);
});

test('API key is stored encrypted and can be deleted', () => {
  const s = mk();
  s.setApiKey('sk-secret');
  assert.equal(s.getApiKey(), 'sk-secret');
  assert.ok(!fs.readFileSync(s.keyFile).toString().includes('sk-secret'));
  assert.ok(!fs.readFileSync(s.settingsFile.replace('settings', 'settings'), { flag: 'a+' }).toString().includes('sk-secret'));
  s.deleteApiKey();
  assert.equal(s.hasApiKey(), false);
  assert.equal(s.getApiKey(), '');
});

test('without secure storage the key is kept in memory only', () => {
  const s = mk({ isEncryptionAvailable: () => false });
  assert.deepEqual(s.setApiKey('k'), { persisted: false });
  assert.equal(s.getApiKey(), 'k');
  assert.equal(fs.existsSync(s.keyFile), false);
});

test('conversations: save, list, rename, delete', () => {
  const s = mk();
  const c = s.saveConversation({ title: 'Hello', messages: [{ role: 'user', content: 'hi' }] });
  assert.equal(s.listConversations().length, 1);
  assert.equal(s.getConversation(c.id).messages[0].content, 'hi');
  s.renameConversation(c.id, 'Renamed');
  assert.equal(s.listConversations()[0].title, 'Renamed');
  s.deleteConversation(c.id);
  assert.equal(s.listConversations().length, 0);
});
